#ifndef LABORATOR_2_4_TESTS_H
#define LABORATOR_2_4_TESTS_H

void run_all_tests();

#endif //LABORATOR_2_4_TESTS_H
