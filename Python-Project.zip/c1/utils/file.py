class File:

    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
    
    def read(self, name: str) -> str:
        """Read from "name" file.
        
        name: str
        return: str
        """
        file = open(name, 'r')
        information = file.read()
        file.close()
        return information
        
    def write(self, name: str, information: str):
        """Write "information" to "name" file.
        
        name: str
        information: str
        """
        file = open(name, 'w')
        file.write(information)
        file.close()
        
class TestFile:
    
    def __init__(self):
        """Give value to class members.
        """
        
        self.__where = "tests/TestFile.in"
        self.__writeThis = "0123456789\nqwertyuiopasdfghjklzxcvbnm"
        
    def test(self):
        """Test File class.
        """
        
        self.__testInit()
        self.__testRead()
        self.__testWrite()
        
    def __testInit(self):
        """Test File __init__ function.
        """
        assert True
        
    def __testRead(self):
        """Test file read function.
        """
        
        a = File()
        
        file = open(self.__where, 'r')
        information = file.read()
        file.close()
        
        assert information == a.read(self.__where)
        
    def __testWrite(self):
        """Test file write function.
        """
        
        a = File()
        a.write(self.__where, self.__writeThis)
        
        assert self.__writeThis == a.read(self.__where)
        
a = TestFile()
a.test()