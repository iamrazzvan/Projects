from repository.memory.student import MemoryStudent
from repository.memory.problem import MemoryProblem
from repository.memory.laborator import MemoryLaborator
from repository.repositoryException import RepositoryException
from domain.entities.laborator import Laborator
from domain.entities.student import Student
from domain.entities.problem import Problem
from domain.entities.laboratorDTO import LaboratorDTO
from domain.validate.validateLaborator import ValidateLaborator
from domain.validate.validateException import ValidateException
from sort.sort import Sort

class LaboratorService:
    def __init__(self, laboratorRepository, laboratorValidate, sRepository, pRepository):
        """Create serivce.
        """
        self.__repository = {}
        self.__repository["laborator"] = laboratorRepository
        self.__repository["student"] = sRepository
        self.__repository["problem"] = pRepository
        self.__validateLaborator = laboratorValidate
        
    def search(self, laboratorIdentification: str, studentIdentification: str):
        """Search the laborator with the number "laboratorIdentification" for the
        student with "studentIdentification" identification.
        
        laboratorIdentification: str
        studentIdentification: str
        return: Laborator
        """
        
        return self.__repository["laborator"].searchLaborator(laboratorIdentification, studentIdentification)
        
    def assign(self, laboratorIdentification: str, studentIdentification: str, problemIdentification: str):
        """Assign the problem with the "problemIdentification" identification to the
        student with the "studentIdentification" identification for the laborator with
        the number "laboratorIdentification".
        
        laboratorIdentification: str
        studentIdentification: str
        problemIdentification: str
        """
        
        laborator = Laborator(laboratorIdentification, studentIdentification, problemIdentification)
        
        self.__validateLaborator.validate(laborator)
        
        self.__repository["laborator"].rememberLaborator(laborator)
        
    def grade(self, laboratorIdentification: str, studentIdentification: str, grade: int):
        """Assign the "grade" grade to the student with the "studentIdentification"
        identification for the laborator with the number "laboratorIdentification".
        
        laboratorIdentification: str
        studentIdentification: str
        grade: int
        """
        
        self.__repository["laborator"].updateLaborator(laboratorIdentification, studentIdentification, grade)
        
    def __returnLaboratorDTO(self, lI: str):
        """Returns all students that have the number in [left, right].
        
        left: int
        right: int
        return: LaboratorsDTO list
        """
        
        laborators = self.__repository["laborator"].returnLaboratorForNumber(lI)
        laboratorsDTO = []
        
        for laborator in laborators:
            sI = laborator.returnStudentIdentification()
            student = self.__repository["student"].searchStudent(sI)
            sN = student.returnName()
            grade = laborator.returnGrade()
            laboratorDTO = LaboratorDTO(lI, sI, sN, grade)
            laboratorsDTO.append(laboratorDTO)
                
        return laboratorsDTO
        
    def sortedName(self, lI: str):
        """Returns student names and their grade values sorted by student name for a laborator.
        
        lI = laboratorIdentification
        
        lI: str
        returns: LaboratorDTO
        """
        
        l = self.__returnLaboratorDTO(lI)
        
        sort = Sort()
        sort.shellSort(l, reverse = False, compareFunction = sort.compareLaboratorName) 
        
        return l
        
    def sortedGrade(self, lI: str):
        """Returns student names and their grade values sorted by grade for a laborator.
        
        lI = laboratorIdentification
        
        lI: str
        returns: LaboratorDTO
        """
        
        l = self.__returnLaboratorDTO(lI)
        
        sort = Sort()
        sort.bubbleSort(l, reverse = True, compareFunction = sort.compareLaboratorGrade)
        return l
        
    def finalGradeUnderFive(self):
        """Returns student names and their final grades for students with final grade < 5.
        
        returns: LaboratorDTO
        """
        
        laborators = self.__repository["laborator"].returnAllLaborators()
        finalGrade = {}
        
        for l in laborators:
            sI = l.returnStudentIdentification()
            grade = l.returnGrade()
            if sI in finalGrade:
                finalGrade[sI][0] += grade
                finalGrade[sI][1] += 1
            else:
                finalGrade[sI] = [grade, 1]
        
        laboratorsDTO = []
        
        for sIdentification, grade in finalGrade.items():
            s = grade[0] // grade[1]
            if s < 5:
                student = self.__repository["student"].searchStudent(sIdentification)
                sN = student.returnName()
                laboratorDTO = LaboratorDTO("-1", sIdentification, sN, s)
                laboratorsDTO.append(laboratorDTO)
        
        return laboratorsDTO
        
    def minimumFinalGrade(self, limit: int):
        """Returns students names and their final grades sorted
        by the final grade. Lower grades are first and are returned only
        "limit" students.
        
        limit: int
        returns: LaboratorDTO
        """
        
        laborators = self.__repository["laborator"].returnAllLaborators()
        finalGrade = {}
        
        for l in laborators:
            sI = l.returnStudentIdentification()
            grade = l.returnGrade()
            if sI in finalGrade:
                finalGrade[sI][0] += grade
                finalGrade[sI][1] += 1
            else:
                finalGrade[sI] = [grade, 1]
        
        laboratorsDTO = []
        
        for sIdentification, grade in finalGrade.items():
            s = grade[0] // grade[1]
            student = self.__repository["student"].searchStudent(sIdentification)
            sN = student.returnName()
            laboratorDTO = LaboratorDTO("-1", sIdentification, sN, s)
            laboratorsDTO.append(laboratorDTO)
        
        sort = Sort()
        sort.bubbleSort(laboratorsDTO, reverse = False, compareFunction = sort.compareLaboratorGrade)
        sortedLaborators = laboratorsDTO
        
        l = []
        c = 0
        
        for laborator in sortedLaborators:
            l.append(laborator)
            c += 1
            if c == limit:
                return l
        
        return l
        
class TestLaboratorService:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
        
    def test(self):
        """Test LaboratorService class.
        """
        
        self.__testInit()
        
        self.__testSearch()
        self.__testAssign()
        self.__testGrade()
        self.__testSortedName()
        self.__testSortedGrade()
        self.__testFinalGradeUnderFive()
        self.__testReturnMinimumFinalGrade()
        
        self.__testReturnLaboratorDTO()
        
    def __testInit(self):
        """Test LaboratorService __init__ function.
        """
        
        lRepository = MemoryLaborator()
        lValidate = ValidateLaborator()
        sRepository = MemoryStudent()
        pRepository = MemoryProblem()
        testThis = LaboratorService(lRepository, lValidate, sRepository, pRepository)
        assert testThis._LaboratorService__repository["laborator"] == lRepository
        assert testThis._LaboratorService__repository["student"] == sRepository
        assert testThis._LaboratorService__repository["problem"] == pRepository
        assert testThis._LaboratorService__validateLaborator == lValidate
        
    def __testSearch(self):
        """Test LaboratorService search function.
        """
        
        lRepository = MemoryLaborator()
        lValidate = ValidateLaborator()
        sRepository = MemoryStudent()
        pRepository = MemoryProblem()
        testThis = LaboratorService(lRepository, lValidate, sRepository, pRepository)
        try:
            testThis.search("1", "3")
            assert False
        except Exception as error:
            assert type(error) == RepositoryException
            assert error.returnErrors() == "Laboratorul nu exista"
        testThis.assign("1", "3", "1_5")
        try:
            a = testThis.search("1", "3")
            assert a.returnLaboratorIdentification() == "1"
            assert a.returnStudentIdentification() == "3"
            assert a.returnProblemIdentification() == "1_5"
        except:
            assert False
        
    def __testAssign(self):
        """Test LaboratorService assign function.
        """
        
        lRepository = MemoryLaborator()
        lValidate = ValidateLaborator()
        sRepository = MemoryStudent()
        pRepository = MemoryProblem()
        testThis = LaboratorService(lRepository, lValidate, sRepository, pRepository)
        try:
            testThis.assign("1", "3", "4_5")
            assert False
        except Exception as error:
            assert type(error) == ValidateException
        try:
            testThis.assign("1", "3", "1_5")
            a = testThis.search("1", "3")
            assert a.returnLaboratorIdentification() == "1"
            assert a.returnStudentIdentification() == "3"
            assert a.returnProblemIdentification() == "1_5"
        except:
            assert False
        
    def __testGrade(self):
        """Test LaboratorService grade function.
        """
        
        lRepository = MemoryLaborator()
        lValidate = ValidateLaborator()
        sRepository = MemoryStudent()
        pRepository = MemoryProblem()
        testThis = LaboratorService(lRepository, lValidate, sRepository, pRepository)
        
        try:
            testThis.grade("1", "1", 10)
            assert False
        except Exception as error:
            assert type(error) == RepositoryException
            assert error.returnErrors() == "Laboratorul nu exista"
        
        testThis.assign("1", "943", "1_1")
        
        try:
            testThis.grade("1", "943", 10)
            assert True
            laborator = testThis.search("1", "943")
            assert laborator.returnLaboratorIdentification() == "1"
            assert laborator.returnStudentIdentification() == "943"
            assert laborator.returnProblemIdentification() == "1_1"
            assert laborator.returnGrade() == 10
        except:
            return False
            
    def __testSortedName(self):
        """Test LaboratorService sortedName function.
        """
        
        student943 = Student("943", "Name Name", "A")
        student93 = Student("93", "A A", "A")
        student94 = Student("94", "Z Z", "A")
        student34 = Student("34", "A Z", "A")
        
        problem = Problem("1_1", "write on screen a number", "11.11.2023")
        
        lRepository = MemoryLaborator()
        
        lValidate = ValidateLaborator()
        
        sRepository = MemoryStudent()
        sRepository.rememberStudent(student943)
        sRepository.rememberStudent(student93)
        sRepository.rememberStudent(student94)
        sRepository.rememberStudent(student34)
        
        pRepository = MemoryProblem()
        pRepository.rememberProblem(problem)
        
        testThis = LaboratorService(lRepository, lValidate, sRepository, pRepository)
        
        testThis.assign("1", "943", "1_1")
        testThis.assign("1", "93", "1_1")
        testThis.assign("1", "94", "1_1")
        testThis.assign("1", "34", "1_1")
        
        testThis.grade("1", "943", 10)
        testThis.grade("1", "93", 8)
        testThis.grade("1", "94", 10)
        testThis.grade("1", "34", 9)
        
        l = testThis.sortedName("1")
        
        l1 = LaboratorDTO("1", "93", "A A", 8)
        l2 = LaboratorDTO("1", "34", "A Z", 9)
        l3 = LaboratorDTO("1", "943", "Name Name", 10)
        l4 = LaboratorDTO("1", "94", "Z Z", 10)
        
        l5 = [l1, l2, l3, l4]
        
        assert len(l) == len(l5)
        
        for i in range(4):
            assert l[i].returnLI() == l5[i].returnLI()
            assert l[i].returnSI() == l5[i].returnSI()
            assert l[i].returnSN() == l5[i].returnSN()
            assert l[i].returnGrade() == l5[i].returnGrade()
        
    def __testSortedGrade(self):
        """Test LaboratorService sortedGrade function.
        """
        
        student943 = Student("943", "Name Name", "A")
        student93 = Student("93", "A A", "A")
        student94 = Student("94", "Z Z", "A")
        student34 = Student("34", "A Z", "A")
        
        problem = Problem("1_1", "write on screen a number", "11.11.2023")
        
        lRepository = MemoryLaborator()
        
        lValidate = ValidateLaborator()
        
        sRepository = MemoryStudent()
        sRepository.rememberStudent(student943)
        sRepository.rememberStudent(student93)
        sRepository.rememberStudent(student94)
        sRepository.rememberStudent(student34)
        
        pRepository = MemoryProblem()
        pRepository.rememberProblem(problem)
        
        testThis = LaboratorService(lRepository, lValidate, sRepository, pRepository)
        
        testThis.assign("1", "943", "1_1")
        testThis.assign("1", "93", "1_1")
        testThis.assign("1", "94", "1_1")
        testThis.assign("1", "34", "1_1")
        
        testThis.grade("1", "943", 10)
        testThis.grade("1", "93", 8)
        testThis.grade("1", "94", 10)
        testThis.grade("1", "34", 9)
        
        l = testThis.sortedGrade("1")
        
        l1 = LaboratorDTO("1", "93", "A A", 8)
        l2 = LaboratorDTO("1", "34", "A Z", 9)
        l3 = LaboratorDTO("1", "943", "Name Name", 10)
        l4 = LaboratorDTO("1", "94", "Z Z", 10)
        
        l5 = [l3, l4, l2, l1]
        
        assert len(l) == len(l5)
        
        for i in range(4):
            assert l[i].returnLI() == l5[i].returnLI()
            assert l[i].returnSI() == l5[i].returnSI()
            assert l[i].returnSN() == l5[i].returnSN()
            assert l[i].returnGrade() == l5[i].returnGrade()
        
    def __testFinalGradeUnderFive(self):
        """Test LaboratorService finalGradeUnderFive function.
        """
        student943 = Student("943", "Name Name", "A")
        student93 = Student("93", "A A", "A")
        student94 = Student("94", "Z Z", "A")
        student34 = Student("34", "A Z", "A")
        
        problem = Problem("1_1", "write on screen a number", "11.11.2023")
        
        lRepository = MemoryLaborator()
        
        lValidate = ValidateLaborator()
        
        sRepository = MemoryStudent()
        sRepository.rememberStudent(student943)
        sRepository.rememberStudent(student93)
        sRepository.rememberStudent(student94)
        sRepository.rememberStudent(student34)
        
        pRepository = MemoryProblem()
        pRepository.rememberProblem(problem)
        
        testThis = LaboratorService(lRepository, lValidate, sRepository, pRepository)
        
        testThis.assign("1", "943", "1_1")
        testThis.assign("1", "93", "1_1")
        testThis.assign("1", "94", "1_1")
        testThis.assign("1", "34", "1_1")
        
        testThis.grade("1", "943", 4)
        testThis.grade("1", "93", 5)
        testThis.grade("1", "94", 3)
        testThis.grade("1", "34", 2)
        
        l = testThis.finalGradeUnderFive()
        
        l1 = LaboratorDTO("-1", "93", "A A", 5)
        l2 = LaboratorDTO("-1", "34", "A Z", 2)
        l3 = LaboratorDTO("-1", "943", "Name Name", 4)
        l4 = LaboratorDTO("-1", "94", "Z Z", 3)
        
        l5 = [l3, l4, l2]
        
        assert len(l) == len(l5)
        
        for i in range(3):
            assert l[i].returnLI() == l5[i].returnLI()
            assert l[i].returnSI() == l5[i].returnSI()
            assert l[i].returnSN() == l5[i].returnSN()
            assert l[i].returnGrade() == l5[i].returnGrade()
            
    def __testReturnLaboratorDTO(self):
        """Test LaboratorService __returnLaboratorDTO function.
        """
        
        student943 = Student("943", "Name Name", "A")
        student93 = Student("93", "A A", "A")
        student94 = Student("94", "Z Z", "A")
        student34 = Student("34", "A Z", "A")
        
        problem = Problem("1_1", "write on screen a number", "11.11.2023")
        
        lRepository = MemoryLaborator()
        
        lValidate = ValidateLaborator()
        
        sRepository = MemoryStudent()
        sRepository.rememberStudent(student943)
        sRepository.rememberStudent(student93)
        sRepository.rememberStudent(student94)
        sRepository.rememberStudent(student34)
        
        pRepository = MemoryProblem()
        pRepository.rememberProblem(problem)
        
        testThis = LaboratorService(lRepository, lValidate, sRepository, pRepository)
        
        testThis.assign("1", "943", "1_1")
        testThis.assign("1", "93", "1_1")
        testThis.assign("1", "94", "1_1")
        testThis.assign("1", "34", "1_1")
        
        testThis.grade("1", "943", 10)
        testThis.grade("1", "93", 8)
        testThis.grade("1", "94", 10)
        testThis.grade("1", "34", 9)
        
        l = testThis._LaboratorService__returnLaboratorDTO("1")
        
        l1 = LaboratorDTO("1", "93", "A A", 8)
        l2 = LaboratorDTO("1", "34", "A Z", 9)
        l3 = LaboratorDTO("1", "943", "Name Name", 10)
        l4 = LaboratorDTO("1", "94", "Z Z", 10)
        
        l5 = [l3, l1, l4, l2]
        
        assert len(l) == len(l5)
        
        for i in range(4):
            assert l[i].returnLI() == l5[i].returnLI()
            assert l[i].returnSI() == l5[i].returnSI()
            assert l[i].returnSN() == l5[i].returnSN()
            assert l[i].returnGrade() == l5[i].returnGrade()
            
    def __testReturnMinimumFinalGrade(self):
        """Test LaboratorService returnMinimumFinalGrade function.
        """
        student943 = Student("943", "Name Name", "A")
        student93 = Student("93", "A A", "A")
        student94 = Student("94", "Z Z", "A")
        student34 = Student("34", "A Z", "A")
        
        problem = Problem("1_1", "write on screen a number", "11.11.2023")
        
        lRepository = MemoryLaborator()
        
        lValidate = ValidateLaborator()
        
        sRepository = MemoryStudent()
        sRepository.rememberStudent(student943)
        sRepository.rememberStudent(student93)
        sRepository.rememberStudent(student94)
        sRepository.rememberStudent(student34)
        
        pRepository = MemoryProblem()
        pRepository.rememberProblem(problem)
        
        testThis = LaboratorService(lRepository, lValidate, sRepository, pRepository)
        
        testThis.assign("1", "943", "1_1")
        testThis.assign("1", "93", "1_1")
        testThis.assign("1", "94", "1_1")
        testThis.assign("1", "34", "1_1")
        
        testThis.grade("1", "943", 4)
        testThis.grade("1", "93", 5)
        testThis.grade("1", "94", 3)
        testThis.grade("1", "34", 2)
        
        l = testThis.minimumFinalGrade(3)
        
        l1 = LaboratorDTO("-1", "93", "A A", 5)
        l2 = LaboratorDTO("-1", "34", "A Z", 2)
        l3 = LaboratorDTO("-1", "943", "Name Name", 4)
        l4 = LaboratorDTO("-1", "94", "Z Z", 3)
        
        l5 = [l2, l4, l3]
        
        assert len(l) == len(l5)
        
        for i in range(3):
            assert l[i].returnLI() == l5[i].returnLI()
            assert l[i].returnSI() == l5[i].returnSI()
            assert l[i].returnSN() == l5[i].returnSN()
            assert l[i].returnGrade() == l5[i].returnGrade()
            
a = TestLaboratorService()
a.test()