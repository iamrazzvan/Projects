from domain.entities.student import Student
from repository.memory.student import MemoryStudent
from repository.repositoryException import RepositoryException
from domain.validate.validateStudent import ValidateStudent
from domain.validate.validateException import ValidateException

class StudentService:
    def __init__(self, repository, validate):
        """Create service.
        """
        self.__repository = repository
        self.__validate = validate
        
    def createStudent(self, identification: str, name: str, group: str):
        """Create a new student with given identification, name and group.
        
        Raises ValidationException if given information is not correct.
        Raises RepositoryException if a student with the
        identification information already exists.
        
        identification: str
        name: str
        group: str
        return: Student
        """
        student = Student(identification, name, group)
        self.__validate.validate(student)
        self.__repository.rememberStudent(student)
        return student
    
    def updateStudent(self, identification: str, newIdentification: str, newName: str, newGroup: str):
        """Update the student with given identification.
        
        Raise ValueError if the given information is not correct.
        Raise RepositoryException if the given identification does not exist.
        
        identification: str
        newIdentification: str
        newName: str
        newGroup: str
        """
        newStudent = Student(newIdentification, newName, newGroup)
        self.__validate.validate(newStudent)
        self.__repository.updateStudent(identification, newStudent)
    
    def searchStudent(self, identification: str):
        """Search student with given identification.
        
        Raise RepositoryException if the student with the
        identification information does not exist.
        
        identification: str
        return: Student
        """
        return self.__repository.searchStudent(identification)
        
    def removeStudent(self, identification: str):
        """Remove student with given identification.
        
        Raise RepositoryException if the student with the
        identification information does not exist.
        
        identification: str
        """
        self.__repository.removeStudent(identification)
        
class TestStudentService:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def test(self):
        """Test StudentService class.
        """
        
        self.__testInit()
        
        self.__testCreateStudent()
        self.__testUpdateStudent()
        self.__testSearchStudent()
        self.__testRemoveStudent()
        
    def __testInit(self):
        """Test StudentService __init__ function.
        """
        assert True
        
    def __testCreateStudent(self):
        """Test StudentService createStudent function.
        """
        studentRepository = MemoryStudent()
        studentValidate = ValidateStudent()
        testThis = StudentService(studentRepository, studentValidate)
        
        try:
            testThis.createStudent("", "", "")
            assert False
            
        except ValidateException:
            assert True
            
        try:
            testThis.createStudent("1", "Name Name", "Group53")
            assert True
            
        except ValidateException:
            assert False
            
        try:
            testThis.createStudent("1", "Name Name", "Group53")
            assert False
            
        except RepositoryException:
            assert True
        
    def __testUpdateStudent(self):
        """Test StudentService updateStudent function.
        """
        studentRepository = MemoryStudent()
        studentValidate = ValidateStudent()
        testThis = StudentService(studentRepository, studentValidate)
        
        testThis.createStudent("identification", "Name Name", "Group53")
        
        try:
            testThis.updateStudent("identification", "newIdentification", "NewName NewName", "newGroup")
            newStudent = testThis.searchStudent("newIdentification")
            assert newStudent.returnIdentification() == "newIdentification"
            assert newStudent.returnName() == "NewName NewName"
            assert newStudent.returnGroup() == "newGroup"
            
        except ValidateException:
            assert False
        
        except RepositoryException:
            assert False
        
        try:
            testThis.updateStudent("identification", "newIdentification", "NewName NewName", "newGroup")
            assert False
            
        except ValidateException:
            assert False
            
        except RepositoryException:
            assert True
            
        try:
            testThis.updateStudent("newIdentification", ";", ";", ";")
            assert False
            
        except ValidateException:
            assert True
            
        except RepositoryException:
            assert False
        
    def __testSearchStudent(self):
        """Test StudentService searchStudent function.
        """
        studentRepository = MemoryStudent()
        studentValidate = ValidateStudent()
        testThis = StudentService(studentRepository, studentValidate)
        
        try:
            testThis.searchStudent("1")
            assert False
            
        except RepositoryException:
            assert True
            
        testThis.createStudent("1", "Name Name", "Group53")
            
        try:
            testThis.searchStudent("1")
            assert True
            
        except RepositoryException:
            assert False
        
    def __testRemoveStudent(self):
        """Test StudentService removeStudent function.
        """
        studentRepository = MemoryStudent()
        studentValidate = ValidateStudent()
        testThis = StudentService(studentRepository, studentValidate)
        
        try:
            testThis.removeStudent("1")
            assert False
            
        except RepositoryException:
            assert True
            
        testThis.createStudent("1", "Name Name", "Group53")
            
        try:
            testThis.removeStudent("1")
            assert True
            
        except RepositoryException:
            assert False
        
a = TestStudentService()
a.test()