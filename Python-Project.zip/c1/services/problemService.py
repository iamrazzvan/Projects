from domain.entities.problem import Problem
from repository.memory.problem import MemoryProblem
from repository.repositoryException import RepositoryException
from domain.validate.validateProblem import ValidateProblem
from domain.validate.validateException import ValidateException
import random

class ProblemService:
    def __init__(self, repository, validate):
        """Creates service.
        """
        self.__repository = repository
        self.__validate = validate
        
    def createProblem(self, identification: str, description: str, timeLimit: str):
        """Create a new problem with given identification, description and timeLimit.
        
        Raises ValidationException if given information is not correct.
        Raises RepositoryException if a problem with the
        identification information already exists.
        
        identification: str
        description: str
        timeLimit: str
        return: Problem
        """
        problem = Problem(identification, description, timeLimit)
        self.__validate.validate(problem)
        self.__repository.rememberProblem(problem)
        return problem
    
    def randomProblem(self, limitForObjects: str):
        """Create "limitForObjects" random problems.
        
        limitForObjects: str
        """
        
        a = random
        
        try:
            
            for i in limitForObjects:
                assert i >= '0' and i <= '9'
                
            limitForObjects = int(limitForObjects)
            assert limitForObjects >= 0
        
        except:
            
            print("Se cere un numar natural")
            return
        
        i = 0
        z = 1
        
        while i < limitForObjects:
        
            i += 1
            
            # identification
            laboratorIdentification = a.randint(1, z)
            problemIdentification = a.randint(1, z)
        
            identification = str(laboratorIdentification) + "_" + str(problemIdentification)
        
            # description
            howMany = a.randint(1, 100)
            description = "Se citesc " + str(howMany) + " numere. Sa fie scrisa pe ecran suma lor."
        
            # time limit
            year = str(a.randint(2023, 2024))
            month = str(a.randint(1, 12))
            day = str(a.randint(1, 20))
            
            if len(month) == 1:
                month = "0" + month
                
            if len(day) == 1:
                day = "0" + day
            
            timeLimit = day + "." + month + "." + year
            
            # remember problem
            try:
            
                self.createProblem(identification, description, timeLimit)
                print("Problema cu legitimatia " + identification + " a fost adaugata")
                
            except:
                
                i = i - 1
                z = z * 10
    
    def updateProblem(self, identification: str, newIdentification: str, newName: str, newGroup: str):
        """Update the problem with given identification.
        
        Raise ValueError if the given information is not correct.
        Raise RepositoryException if the given identification does not exist.
        
        identification: str
        newIdentification: str
        newName: str
        newGroup: str
        """
        newProblem = Problem(newIdentification, newName, newGroup)
        self.__validate.validate(newProblem)
        self.__repository.updateProblem(identification, newProblem)
    
    def searchProblem(self, identification: str):
        """Search problem with given identification.
        
        Raise RepositoryException if the problem with the
        identification information does not exist.
        
        identification: str
        return: Problem
        """
        return self.__repository.searchProblem(identification)
    
    def removeProblem(self, identification: str):
        """Remove problem with given identification.
        
        Raise RepositoryException if the problem with the
        identification information does not exist.
        
        identification: str
        """
        self.__repository.removeProblem(identification)
        
class TestProblemService:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def test(self):
        """Test ProblemService class.
        """
        
        self.__testInit()
        
        self.__testCreateProblem()
        self.__testUpdateProblem()
        self.__testSearchProblem()
        self.__testRemoveProblem()
        
    def __testInit(self):
        """Test ProblemService __init__ function.
        """
        assert True
        
    def __testCreateProblem(self):
        """Test ProblemService createProblem function.
        """
        problemRepository = MemoryProblem()
        problemValidate = ValidateProblem()
        testThis = ProblemService(problemRepository, problemValidate)
        
        try:
            testThis.createProblem("", "", "")
            assert False
            
        except ValidateException:
            assert True
            
        try:
            testThis.createProblem("1_43", "description", "11.11.2023")
            assert True
            
        except ValidateException:
            assert False
            
        try:
            testThis.createProblem("1_43", "description", "11.11.2023")
            assert False
            
        except RepositoryException:
            assert True
        
    def __testUpdateProblem(self):
        """Test ProblemService updateProblem function.
        """
        problemRepository = MemoryProblem()
        problemValidate = ValidateProblem()
        testThis = ProblemService(problemRepository, problemValidate)
        
        testThis.createProblem("3_43", "Description", "11.11.2023")
        
        try:
            testThis.updateProblem("3_43", "3_53", "newDescription", "20.11.2023")
            newProblem = testThis.searchProblem("3_53")
            assert newProblem.returnIdentification() == "3_53"
            assert newProblem.returnDescription() == "newDescription"
            assert newProblem.returnTimeLimit() == "20.11.2023"
            
        except ValidateException:
            assert False
        
        except RepositoryException:
            assert False
        
        try:
            testThis.updateProblem("3_43", "3_53", "newDescription", "20.11.2023")
            assert False
            
        except ValidateException:
            assert False
            
        except RepositoryException:
            assert True
            
        try:
            testThis.updateProblem("3_53", ";", ";", ";")
            assert False
            
        except ValidateException:
            assert True
            
        except RepositoryException:
            assert False
        
    def __testSearchProblem(self):
        """Test ProblemService searchProblem function.
        """
        problemRepository = MemoryProblem()
        problemValidate = ValidateProblem()
        testThis = ProblemService(problemRepository, problemValidate)
        
        try:
            testThis.searchProblem("1")
            assert False
            
        except RepositoryException:
            assert True
            
        testThis.createProblem("1_43", "description", "11.11.2023")
            
        try:
            testThis.searchProblem("1_43")
            assert True
            
        except RepositoryException:
            assert False
        
    def __testRemoveProblem(self):
        """Test ProblemService removeProblem function.
        """
        problemRepository = MemoryProblem()
        problemValidate = ValidateProblem()
        testThis = ProblemService(problemRepository, problemValidate)
        
        try:
            testThis.removeProblem("1")
            assert False
            
        except RepositoryException:
            assert True
            
        testThis.createProblem("1_43", "description", "11.11.2023")
            
        try:
            testThis.removeProblem("1_43")
            assert True
            
        except RepositoryException:
            assert False
        
a = TestProblemService()
a.test()