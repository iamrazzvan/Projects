from domain.entities.laboratorDTO import LaboratorDTO

class Sort:
    
    def compareInt(self, a: int, b: int, reverse: bool = False):
        
        """Compares two integers
        
        a: int
        b: int
        reverse: bool
        return: bool
        """
        
        if reverse:
            
            return a > b
            
        return a < b
        
    def compareLaboratorGrade(self, a, b, reverse: bool = False):
        
        """Compares two laboratorDTO grades
        
        a: laboratorDTO
        b: laboratorDTO
        reverse: bool
        return: bool
        """
        
        return self.compareInt(a.returnGrade(), b.returnGrade(), reverse)
        
    def compareLaboratorName(self, a, b, reverse: bool = False):
        
        """Compares two laboratorDTO names
        
        a: laboratorDTO
        b: laboratorDTO
        reverse: bool
        return: bool
        """
        
        if reverse:
        
            return a.returnNameNoSpace() > b.returnNameNoSpace()
            
        return a.returnNameNoSpace() < b.returnNameNoSpace()
        
    def bubbleSort(self, this: list, /, *, reverse: bool = False, compareFunction):
        
        """Sorts this using compareFunction
        
        this: list
        compareFunction: function
        reverse: bool
        """
        
        # en.wikipedia.org/wiki/Bubble_sort
        
        # complexity
        
        # n = this size
        
        # time
        
        # worst case
        # O(n power 2) comparisons, O(n power 2) swaps
        # average case
        # O(n power 2) comparisons, O(n power 2) swaps
        # best case
        # O(n) comparisons, O(1) swaps
        
        # worst case
        # omega(n power 2) comparisons, omega(n power 2) swaps
        # average case
        # omega(n power 2) comparisons, omega(n power 2) swaps
        # best case
        # omega(n) comparisons, omega(1) swaps
        
        # worst case
        # theta(n power 2) comparisons, theta(n power 2) swaps
        # average case
        # theta(n power 2) comparisons, theta(n power 2) swaps
        # best case
        # theta(n) comparisons, theta(1) swaps
        
        # memory
        
        # O(n) total memory, O(1) auxiliary
        # worst case = average case = best case
        
        # omega(n) total memory, O(1) auxiliary
        # worst case = average case = best case
        
        # theta(n) total memory, theta(1) auxiliary
        # worst case = average case = best case
        
        limit = len(this)
        
        while limit:
            
            newLimit = 0
            
            for i in range(1, limit):
                
                if compareFunction(this[i], this[i - 1], reverse):
                    
                    aux = this[i - 1]
                    this[i - 1] = this[i]
                    this[i] = aux
                    newLimit = i
                    
            limit = newLimit
    
    def shellSortRecursive(self, this: list, reverse: bool, compareFunction, s: int, l: int):
        
        """Sorts this using compareFunction
        
        this: list
        compareFunction: function
        reverse: bool
        s (space): int
        l (space limit): int
        """
        
        # en.wikipedia.org/wiki/Shellsort
        
        if s > l:
            
            return
        
        self.shellSortRecursive(this, reverse, compareFunction, s * 2, l)
        
        limit = len(this)
        
        for i in range(s, limit):
            
            aux = this[i]
                
            j = i
                
            while j >= s and compareFunction(aux, this[j - s], reverse):
                    
                this[j] = this[j - s]
                j -= s
                
            this[j] = aux
    
    def shellSort(self, this: list, /, *, reverse: bool = False, compareFunction):
        
        """Sorts this using compareFunction
        
        this: list
        compareFunction: function
        reverse: bool
        """
        
        self.shellSortRecursive(this, reverse, compareFunction, 1, 1024)
        
class TestSort:
    
    def test(self):
        
        """Test Sort class
        """
        
        self.testCompareInt()
        self.testCompareLaboratorGrade()
        self.testCompareLaboratorName()
        self.testBubbleSort()
        self.testShellSort()
        
    def testCompareInt(self):
        
        """Test compareInt
        """
        
        sort = Sort()
        
        assert sort.compareInt(0, 1) == 1
        assert sort.compareInt(1, 0) == 0
        assert sort.compareInt(0, 1, True) == 0
        assert sort.compareInt(1, 0, True) == 1
        
    def testCompareLaboratorGrade(self):
        
        """Test compareLaboratorGrade
        """
        
        sort = Sort()
        
        numbers = ["0", "1"]
        
        laborators = []
        
        for number in numbers:
            
            laborator = LaboratorDTO("", "", "", number)
            laborators.append(laborator)
        
        assert sort.compareLaboratorGrade(laborators[0], laborators[1], False) == 1
        assert sort.compareLaboratorGrade(laborators[1], laborators[0], False) == 0
        assert sort.compareLaboratorGrade(laborators[0], laborators[1], True) == 0
        assert sort.compareLaboratorGrade(laborators[1], laborators[0], True) == 1
        
    def testCompareLaboratorName(self):
        
        """Test compareLaboratorName
        """
        
        sort = Sort()
        
        characters = ["a a", "b b"]
        
        laborators = []
        
        for c in characters:
            
            laborator = LaboratorDTO("", "", c, "")
            laborators.append(laborator)
        
        assert sort.compareLaboratorName(laborators[0], laborators[1], False) == 1
        assert sort.compareLaboratorName(laborators[1], laborators[0], False) == 0
        assert sort.compareLaboratorName(laborators[0], laborators[1], True) == 0
        assert sort.compareLaboratorName(laborators[1], laborators[0], True) == 1
        
    def testBubbleSort(self):
    
        """Test bubbleSort
        """
        
        sort = Sort()
        
        # test 1
        array = [1, 2, 3, 4, 5]
        sort.bubbleSort(array, compareFunction = sort.compareInt)
        assert array == [1, 2, 3, 4, 5]
        
        # test 2
        array = []
        sort.bubbleSort(array, compareFunction = sort.compareInt)
        assert array == []
        
        # test 3
        array = [1, 2, 3, 4, 5]
        sort.bubbleSort(array, reverse = True, compareFunction = sort.compareInt)
        assert array == [5, 4, 3, 2, 1]
        
        # test 4
        array = [0, -5, 30, 100]
        sort.bubbleSort(array, reverse = True, compareFunction = sort.compareInt)
        assert array == [100, 30, 0, -5]

    def testShellSort(self):
    
        """Test shellSort
        """
        
        sort = Sort()
        
        # test 1
        array = [1, 2, 3, 4, 5]
        sort.shellSort(array, compareFunction = sort.compareInt)
        assert array == [1, 2, 3, 4, 5]
        
        # test 2
        array = []
        sort.shellSort(array, compareFunction = sort.compareInt)
        assert array == []
        
        # test 3
        array = [1, 2, 3, 4, 5]
        sort.shellSort(array, reverse = True, compareFunction = sort.compareInt)
        assert array == [5, 4, 3, 2, 1]
        
        # test 4
        array = [0, -5, 30, 100]
        sort.shellSort(array, reverse = True, compareFunction = sort.compareInt)
        assert array == [100, 30, 0, -5]
    
a = TestSort()
a.test()