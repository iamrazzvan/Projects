from domain.validate.validateException import ValidateException
from repository.repositoryException import RepositoryException
from utils.file import File
from domain.validate.validateGrade import ValidateGrade

class Console:
    def __init__(self, services: dict):
        """Creates a new console ui.
        
        services: dict
        """
        self.__services = services
        self.__write = File()
    
    def __readStudentIdentification(self):
        """Read student identificaton from keyboard.
        """
        return input(self.__write.read("write/studentIdentification.in"))
        
    def __readStudentName(self):
        """Read student name from keyboard.
        """
        return input(self.__write.read("write/studentName.in"))
        
    def __readStudentGroup(self):
        """Read student group from keyboard.
        """
        return input(self.__write.read("write/studentGroup.in"))
    
    def __readStudentWhat(self):
        """Read what to change for student information.
        """
        return input(self.__write.read("write/studentWhat.in"))
    
    def __readProblemIdentification(self):
        """Read problem identification from keyboard.
        """
        return input(self.__write.read("write/problemIdentification.in"))
        
    def __readProblemDescription(self):
        """Read problem description from keyboard.
        """
        return input(self.__write.read("write/problemDescription.in"))
        
    def __readProblemTimeLimit(self):
        """Read problem time limit from keyboard.
        """
        return input(self.__write.read("write/problemTimeLimit.in"))   
    
    def __readProblemWhat(self):
        """Read what to change for problem information.
        """
        return input(self.__write.read("write/problemWhat.in"))
     
    def __readLaboratorIdentification(self):
        """Read laborator identification from keyboard.
        """
        return input(self.__write.read("write/laboratorIdentification.in"))
     
    def __readGrade(self):
        """Read a number for a grade from keyboard.
        """
        return input(self.__write.read("write/grade.in"))
     
    def __help(self):
        """Writes help information.
        """
        
        for i in range(5):
            print(self.__write.read("help/help" + str(i) + ".in"))
        
        for i in range(13):
            print(self.__write.read("help/help5" + str(i) + ".in"))
    
    def __newStudentInformation(self):
        """Read new student from console and remember the student.
        """
        identification = self.__readStudentIdentification()
        name = self.__readStudentName()
        group = self.__readStudentGroup()
        
        try:
            student = self.__services["student"].createStudent(identification, name, group)
            print("Studentul a fost adaugat")
            
        except ValidateException as error:
            print(error.returnErrors())
            
        except RepositoryException as error:
            print(error.returnErrors())
        
    def __changeStudentInformation(self):
        """Change student information.
        """
        identification = self.__readStudentIdentification()
        
        try:
        
            student = self.__services["student"].searchStudent(identification)
        
        except RepositoryException as error:
        
            print(error.returnErrors())
            return
        
        what = self.__readStudentWhat()
        
        if what != "legitimatie" and what != "nume" and what != "grup":
            print("Se accepta pentru schimbare doar legitimatia, numele sau grupul")
            return
        
        newIdentification = student.returnIdentification()
        newName = student.returnName()
        newGroup = student.returnGroup()
            
        if what == "legitimatie":
            newIdentification = self.__readStudentIdentification()
        
        if what == "nume":
            newName = self.__readStudentName()
            
        if what == "grup":
            newGroup = self.__readStudentGroup()
            
        try:
            self.__services["student"].updateStudent(identification, newIdentification, newName, newGroup)
            print("Informatiile au fost schimbate")
            
        except ValidateException as error:
            print(error.returnErrors())
            
        except RepositoryException as error:
            print(error.returnErrors())
        
    def __removeStudentInformation(self):
        """Remove student informtion.
        """
        identification = self.__readStudentIdentification()
        
        try:
            self.__services["student"].removeStudent(identification)
            print("Studentul a fost sters")
            
        except RepositoryException as error:
            print(error.returnErrors())
    
    def __newProblemInformation(self):
        """Read new problem from console and remember the problem.
        """
        identification = self.__readProblemIdentification()
        description = self.__readProblemDescription()
        timeLimit = self.__readProblemTimeLimit()
        
        try:
            problem = self.__services["problem"].createProblem(identification, description, timeLimit)
            print("Problema a fost adaugata")
            
        except ValidateException as error:
            print(error.returnErrors())
            
        except RepositoryException as error:
            print(error.returnErrors())
        
    def __changeProblemInformation(self):
        """Change problem information.
        """
        identification = self.__readProblemIdentification()
        
        try:
        
            problem = self.__services["problem"].searchProblem(identification)
        
        except RepositoryException as error:
        
            print(error.returnErrors())
            return
        
        what = self.__readProblemWhat()
        
        if what != "legitimatie" and what != "descriere" and what != "limita":
            print("Se accepta pentru schimbare doar legitimatia, descrierea sau limita")
            return
        
        newIdentification = problem.returnIdentification()
        newDescription = problem.returnDescription()
        newTimeLimit = problem.returnTimeLimit()
            
        if what == "legitimatie":
            newIdentification = self.__readProblemIdentification()
        
        if what == "descriere":
            newDescription = self.__readProblemDescription()
            
        if what == "limita":
            newTimeLimit = self.__readProblemTimeLimit()
        
        try:
            self.__services["problem"].updateProblem(identification, newIdentification, newDescription, newTimeLimit)
            print("Informatiile au fost schimbate")
            
        except ValidateException as error:
            print(error.returnErrors())
            
        except RepositoryException as error:
            print(error.returnErrors())
        
    def __removeProblemInformation(self):
        """Remove problem information.
        """
        identification = self.__readProblemIdentification()
        
        try:
            self.__services["problem"].removeProblem(identification)
            print("Problema a fost stearsa")
            
        except RepositoryException as error:
            print(error.returnErrors())
    
    def __searchStudentInformation(self):
        """Search student information.
        """
        identification = self.__readStudentIdentification()
        
        try:
            searchedStudent = self.__services["student"].searchStudent(identification)
            familyName = searchedStudent.returnFamilyName()
            notFamilyName = searchedStudent.returnNotFamilyName()
            group = searchedStudent.returnGroup()
            
            print("Studentul cu legitimatia ", end = '')
            print(identification, end = '')
            print(" are", end = '\n')
            
            print("nume: ", end = '')
            print(familyName, end = '\n')
            
            print("prenume: ", end = '')
            print(notFamilyName, end = '\n')
            
            print("grup: ", end = '')
            print(group, end = '\n')
        
        except RepositoryException as error:
            print(error.returnErrors())
        
    def __searchProblemInformation(self):
        """Search problem information.
        """
        identification = self.__readProblemIdentification()
        
        try:
            searchedProblem = self.__services["problem"].searchProblem(identification)
            description = searchedProblem.returnDescription()
            timeLimit = searchedProblem.returnTimeLimit()
            
            print("Problema cu legitimatia ", end = '')
            print(identification, end = '')
            print(" are", end = '\n')
            
            print("\nDescriere", end = '\n')
            print(description, end = '\n')
            
            print("\nTermenul limita", end = '\n')
            print(timeLimit, end = '\n')
            
        except RepositoryException as error:
            print(error.returnErrors())
    
    def __newLaborator(self):
        """Give new laborator to a student.
        """
        print("Se va cere numar laborator, legitimatie student, legitimatie problema")
        laboratorIdentification = self.__readLaboratorIdentification()
        sIdentification = self.__readStudentIdentification()
        pIdentification = self.__readProblemIdentification()
        try:
            self.__services["student"].searchStudent(sIdentification)
            self.__services["problem"].searchProblem(pIdentification)
            self.__services["laborator"].assign(laboratorIdentification, sIdentification, pIdentification)
            print("Laboratorul a fost atribuit")
        except ValidateException as error:
            print(error.returnErrors())
        except RepositoryException as error:
            print(error.returnErrors()) 
        
    def __newLaboratorResults(self):
        """Create the results for a laborator.
        """
        print("Se va cere numar laborator, legitimatie student, nota")
        laboratorIdentification = self.__readLaboratorIdentification()
        studentIdentification = self.__readStudentIdentification()
        number = self.__readGrade()
        validateGrade = ValidateGrade()
        try:
            validateGrade.validate(number)
            n = int(number)
            self.__services["laborator"].search(laboratorIdentification, studentIdentification)
            self.__services["student"].searchStudent(studentIdentification)
            self.__services["laborator"].grade(laboratorIdentification, studentIdentification, n)
            print("Nota pentru laborator a fost adaugata")
        except ValidateException as error:
            print(error.returnErrors())
        except RepositoryException as error:
            print(error.returnErrors())
    
    def __searchNameForLaborator(self):
        """Writes all students for a laborator sorted by name.
        """
        
        lI = self.__readLaboratorIdentification()
        print("Laboratorul", end = " ")
        print(lI, end = "\n")
        for l in self.__services["laborator"].sortedName(lI):
            print(l.returnSN(), end = " ")
            print(l.returnGrade(), end = "\n")
        
    def __searchGradeForLaborator(self):
        """Write all students for a laborator sorted by grade.
        """
        
        lI = self.__readLaboratorIdentification()
        print("Laboratorul", end = " ")
        print(lI, end = "\n")
        for l in self.__services["laborator"].sortedGrade(lI):
            print(l.returnSN(), end = " ")
            print(l.returnGrade(), end = "\n")
        
    def __searchFinalGrade(self):
        """Writes all students with the final grade < 5.
        """
        
        for l in self.__services["laborator"].finalGradeUnderFive():
            print(l.returnSN(), end = " ")
            print(l.returnGrade(), end = "\n")
    
    def __searchMinimumFinalGrade(self):
        """Search students with minimum final grade and write on screen
        first 5 students with minimum final grade.
        """
        
        for l in self.__services["laborator"].minimumFinalGrade(5):
            print(l.returnSN(), end = " ")
            print(l.returnGrade(), end = "\n")
    
    def __random(self):
        """Add random problems.
        """
        
        limitForObjects = input("Citeste cate probleme sa fie adaugata la intamplare\n")
        
        problem = self.__services["problem"].randomProblem(limitForObjects)
        
    def run(self):
        while True:
            action = input(self.__write.read("write/actions.in"))
            match action:
                case "ajutor":
                    self.__help()
                case "adaugaStudent":
                    self.__newStudentInformation()
                case "modificaStudent":
                    self.__changeStudentInformation()
                case "stergeStudent":
                    self.__removeStudentInformation()
                case "adaugaProblema":
                    self.__newProblemInformation()
                case "modificaProblema":
                    self.__changeProblemInformation()
                case "stergeProblema":
                    self.__removeProblemInformation()
                case "cautaStudent":
                    self.__searchStudentInformation()
                case "cautaProblema":
                    self.__searchProblemInformation()
                case "atribuireLaborator":
                    self.__newLaborator()
                case "notareLaborator":
                    self.__newLaboratorResults()
                case "aranjatNume":
                    self.__searchNameForLaborator()
                case "aranjatNota":
                    self.__searchGradeForLaborator()
                case "cautaMedie":
                    self.__searchFinalGrade()
                case "aranjatMedie":
                    self.__searchMinimumFinalGrade()
                case "laIntamplare":
                    self.__random()
                case "iesire":
                    break
                case _:
                    print("Comanda nu exista")