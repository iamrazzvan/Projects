from domain.entities.student import Student
from domain.validate.validateException import ValidateException

class ValidateStudent():
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def validate(self, student):
        """Raises ValidateException if student information is not correct.
        
        student: Student
        """
        errors = ""
        
        searchFor = []
        searchFor.append(self.__validateIdentification)
        searchFor.append(self.__validateName)
        searchFor.append(self.__validateGroup)
        
        for validateThis in searchFor:
        
            error = validateThis(student)
            
            if error != "":
                errors += error + "\n"
                
        if errors != "":
            raise ValidateException(errors)
    
    def __validateIdentification(self, student) -> str:
        """Returns string error if student's identification
        is not correct or empty string if it is correct.
        
        student: Student
        return: str
        """
        identification = student.returnIdentification()
        
        if identification == "":
            return "Se cere pentru legitimatie cel putin o litera sau o cifra"
        
        if identification.isalnum() == False:
            return "Legitimatia trebuie sa contina doar cifre si litere"
        
        # if legitimation exists
        
        return ""
    
    def __validateFamilyName(self, name: str) -> str:
        """Returns string error if student's family name
        is not correct or empty string if it is correct.
        
        name: str
        return: str
        """
        
        if name == "":
            return "Se cere pentru nume cel putin o litera"
            
        if name.isalpha() == False:
            return "Numele trebuie sa contina doar litere"
            
        return ""
        
    def __validateNotFamilyName(self, name: str) -> str:
        """Returns string error if student's not family name
        is not correct or empty string if it is correct.
        
        name: str
        return: str
        """
        
        if name == "":
            return "Se cere pentru prenume cel putin o litera"
            
        if name.isalpha() == False:
            return "Prenumele trebuie sa contina doar litere"
            
        return ""
    
    def __validateName(self, student) -> str:
        """Returns string error if student's name
        is not correct or empty string if it is correct.
        
        student: Student
        return: str
        """
        name = student.returnName()
        
        fragments = name.partition(" ")
        
        firstError = self.__validateFamilyName(fragments[0])
        secondError = self.__validateNotFamilyName(fragments[2])
        
        if firstError == "" and secondError == "":
            return ""
            
        return firstError + '\n' + secondError
        
    def __validateGroup(self, student) -> str:
        """Returns string error if student's group
        is not correct or empty string if it is correct.
        
        student: Student
        return: str
        """
        group = student.returnGroup()
        
        if group == "":
            return "Se cere pentru grup cel putin o litera sau o cifra"
        
        if group.isalnum() == False:
            return "Grupul trebuie sa contina doar cifre si litere"
            
        return ""

class TestValidateStudent:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def test(self):
        """Test ValiateStudent class.
        """
        
        self.__testInit()
        
        self.__testValidateIdentification()
        self.__testValidateFamilyName()
        self.__testValidateNotFamilyName()
        self.__testValidateName()
        self.__testValidateGroup()
        
        self.__testValidate()
        
    def __testInit(self):
        """Test ValidateStudent __init__ function.
        """
        assert True
        
    def __testValidateIdentification(self):
        """Test ValidateStudent __validateIdentification function.
        """
        error1 = "Se cere pentru legitimatie cel putin o litera sau o cifra"
        error2 = "Legitimatia trebuie sa contina doar cifre si litere"
        testThis = ValidateStudent()
        
        student = Student("", "", "")
        assert testThis._ValidateStudent__validateIdentification(student) == error1
        
        student = Student(";", "", "")
        assert testThis._ValidateStudent__validateIdentification(student) == error2
        
    def __testValidateFamilyName(self):
        """Test ValidateStudent __validateFamilyName function.
        """
        error1 = "Se cere pentru nume cel putin o litera"
        error2 = "Numele trebuie sa contina doar litere"
        testThis = ValidateStudent()
        
        assert testThis._ValidateStudent__validateFamilyName("") == error1
        
        assert testThis._ValidateStudent__validateFamilyName(";") == error2
        
    def __testValidateNotFamilyName(self):
        """Test ValidateStudent __validateNotFamilyName function.
        """
        error1 = "Se cere pentru prenume cel putin o litera"
        error2 = "Prenumele trebuie sa contina doar litere"
        testThis = ValidateStudent()
        
        assert testThis._ValidateStudent__validateNotFamilyName("") == error1
        
        assert testThis._ValidateStudent__validateNotFamilyName(";") == error2
        
    def __testValidateName(self):
        """Test ValidateStudent __validateName function.
        """
        error1 = "Se cere pentru nume cel putin o litera"
        error2 = "Numele trebuie sa contina doar litere"
        error3 = "Se cere pentru prenume cel putin o litera"
        error4 = "Prenumele trebuie sa contina doar litere"
        testThis = ValidateStudent()
        
        student = Student("", "", "")
        assert testThis._ValidateStudent__validateName(student) == (error1 + "\n" + error3)
        
        student = Student("", "; ;", "")
        assert testThis._ValidateStudent__validateName(student) == (error2 + "\n" + error4)
        
    def __testValidateGroup(self):
        """Test ValidateStudent __validateGroup function.
        """
        error1 = "Se cere pentru grup cel putin o litera sau o cifra"
        error2 = "Grupul trebuie sa contina doar cifre si litere"
        testThis = ValidateStudent()
        
        student = Student("", "", "")
        assert testThis._ValidateStudent__validateGroup(student) == error1
        
        student = Student("", "", ";")
        assert testThis._ValidateStudent__validateGroup(student) == error2
        
    def __testValidate(self):
        """Test ValiateStudent validate function.
        """
        testThis = ValidateStudent()
        error1 = "Se cere pentru legitimatie cel putin o litera sau o cifra"
        error2 = "Se cere pentru nume cel putin o litera"
        error3 = "Se cere pentru prenume cel putin o litera"
        error4 = "Se cere pentru grup cel putin o litera sau o cifra"
        
        student = Student("", "", "")
        
        try:
            testThis.validate(student)
            assert False
            
        except ValidateException:
            assert True
        
a = TestValidateStudent()
a.test()