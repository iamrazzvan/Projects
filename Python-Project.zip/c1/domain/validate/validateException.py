class ValidateException(Exception):
    
    def __init__(self, errors: str):
        """Creates new ValidatonException using the given errors.
        
        errors: str
        """
        self.newErrors(errors)
        
    def newErrors(self, errors: str):
        """Gives new errors.
        """
        self.__errors = errors
        
    def returnErrors(self) -> str:
        """Returns errors.
        
        return: str
        """
        return self.__errors
        
class TestValidateException():
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def test(self):
        """Test ValidateException class.
        """
        
        self.__testNewErrors()
        
        self.__testReturnErrors()
        
        self.__testInit()
        
    def __testNewErrors(self):
        """Test ValidateException newErrors function.
        """
        testThis = ValidateException("errors")
        testThis.newErrors("newErrors")
        assert testThis._ValidateException__errors == "newErrors"
        
    def __testReturnErrors(self):
        """Test ValidateException returnErrors function.
        """
        testThis = ValidateException("errors")
        testThis._ValidateException__errors = "newErrors"
        assert testThis.returnErrors() == "newErrors"
        
    def __testInit(self):
        """Test ValidateException __init__ function.
        """
        testThis = ValidateException("errors")
        assert testThis.returnErrors() == "errors"
        
a = TestValidateException()
a.test()