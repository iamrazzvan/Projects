from domain.entities.laborator import Laborator
from domain.validate.validateException import ValidateException


class ValidateLaborator:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
        
    def validate(self, laborator):
        """Raises ValidationException if laborator information is not correct.
        
        laborator: Laborator
        """
        
        try:
            laboratorIdentification = laborator.returnLaboratorIdentification()
            aux = int(laboratorIdentification)
            assert aux > 0
        except:
            raise ValidateException("Se cere pentru numarul de laborator un numar natural > 0")
        
        problemIdentification = laborator.returnProblemIdentification()
        fragments = problemIdentification.split("_")
        laboratorNumber = fragments[0]
        try:
            assert laboratorNumber == laboratorIdentification
        except:
            raise ValidateException("Aceasta problema nu este pentru laboratorul citit")
        
class TestValidateLaborator:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
        
    def test(self):
        """Test ValidateLaborator class.
        """
        
        self.__testInit()
        self.__testValidate()
        
    def __testInit(self):
        """Test ValidateLaborator __init__ function.
        """
        assert True
        
    def __testValidate(self):
        """Test ValidateLaborator validate function.
        """
        testThis = ValidateLaborator()
        laborator1 = Laborator("1", "3", "1_5")
        try:
            testThis.validate(laborator1)
            assert True
        except:
            assert False
        laborator2 = Laborator("F", "3", "4_5")
        try:
            testThis.validate(laborator2)
            assert False
        except Exception as error:
            assert type(error) == ValidateException
            assert error.returnErrors() == "Se cere pentru numarul de laborator un numar natural > 0"
        laborator3 = Laborator("1", "3", "4_5")
        try:
            testThis.validate(laborator3)
            assert False
        except Exception as error:
            assert type(error) == ValidateException
            assert error.returnErrors() == "Aceasta problema nu este pentru laboratorul citit"
        
a = TestValidateLaborator()
a.test()