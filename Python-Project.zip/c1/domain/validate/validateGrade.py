from domain.validate.validateException import ValidateException

class ValidateGrade:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
        
    def validate(self, grade: str):
        """Raise ValidateException if grade information is not correct.
        
        grade: str
        """
        try:
            assert type(grade) == str
            number = int(grade)
            assert number >= 1
            assert number <= 10
        except:
            raise ValidateException("Se cere pentu nota un numar natural a, 1 <= a <= 10")
            
class TestValidateGrade:

    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
        
    def test(self):
        """Test ValidateGrade class.
        """
        
        self.__testInit()
        self.__testValidate()
        
    def __testInit(self):
        """Test ValidateGrade __init__ function.
        """
        assert True
        
    def __testValidate(self):
        """Test ValidateGrade validate function.
        """
        
        testThis = ValidateGrade()
        
        notGradeNumbers = ["0", "A", "-1", 10]
        
        for i in notGradeNumbers:
            try:
                testThis.validate(i)
                assert False
            except Exception as error:
                assert type(error) == ValidateException
                assert error.returnErrors() == "Se cere pentu nota un numar natural a, 1 <= a <= 10"
                
        for i in range(1, 11):
            j = str(i)
            try:
                testThis.validate(j)
                assert True
            except:
                assert False
                
a = TestValidateGrade()
a.test()