from domain.entities.problem import Problem
from domain.validate.validateException import ValidateException
import datetime

class ValidateProblem():
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
    
    def __isNumber(self, this: str) -> bool:
        """Returns true if this is a number and false otherwise.
        
        this: str
        return: bool
        """
        
        # complexity
        
        # n = this size
        
        # time
        
        # O(n)
        # worst case = average case = best case
        
        # omega(n)
        # worst case = average case = best case
        
        # theta(n)
        # worst case = average case = best case
        
        # memory
        
        # O(n)
        # worst case = average case = best case
        
        # omega(n)
        # worst case = average case = best case
        
        # theta(n)
        # worst case = average case = best case
        
        if len(this) == 0:
            return True
        
        if this[0] < '0' or this[0] > '9':
            return False
        
        q = []
        
        for i in range(1, len(this)):
            
            q.append(this[i])
        
        q = ''.join(q)
        
        return self.__isNumber(q)
    
    def validate(self, problem) -> str:
        """Raises ValidatonException if problem information is not correct.
        
        problem: Problem
        """
        errors = ""
        
        searchFor = []
        searchFor.append(self.__validateIdentification)
        searchFor.append(self.__validateDescription)
        searchFor.append(self.__validateTimeLimit)
        
        for validateThis in searchFor:
            
            error = validateThis(problem)
            
            if error != "":
                errors += error + "\n"
                
        if error != "":
            raise ValidateException(errors)
        
    def __validateIdentification(self, problem) -> str:
        """Returns string error if problem's identification
        is not correct or empty string if it is correct.
        
        problem: Problem
        return: str
        """
        identification = problem.returnIdentification()
        
        fragments = identification.partition("_")
        
        if fragments[1] == "":
            return "Legitimatia nu are forma ceruta"
            
        for i in range(0, 3, 2):
            if fragments[i].isnumeric() == False:
                return 'Legitimatia trebuie sa contina doar cifre si "_"'
        
        return ""
        
    def __validateDescription(self, problem) -> str:
        """Returns string error if problem's description
        is not correct or empty string if it is correct.
        
        problem: Problem
        return: str
        """
        description = problem.returnDescription()
        
        if description == "":
            return "Descrierea trebuie sa nu lipseasca"
            
        return ""
        
    def __validateTimeLimit(self, problem) -> str:
        """Returns string error if problem's timeLimit
        is not correct or empty string if it is correct.
        
        problem: Problem
        return: str
        """
        timeLimit = problem.returnTimeLimit()
        
        fragments = timeLimit.partition(".")
        
        if fragments[0] == "" or fragments[2] == "":
            return "Limita de predare nu are forma ceruta"
        
        fragmentsTwo = fragments[2].partition(".")
        
        if fragmentsTwo[0] == "" or fragmentsTwo[2] == "":
            return "Limita de predare nu are froma ceruta"
        
        day = fragments[0]
        month = fragmentsTwo[0]
        year = fragmentsTwo[2]
        
        if '.' in day or '.' in month or '.' in year:
            return "Limita de predare nu are forma ceruta"
        
        if self.__isNumber(day) == False:
            return 'Limita de predare trebuie sa contina doar cifre si "."'
            
        if self.__isNumber(month) == False:
            return 'Limita de predare trebuie sa contina doar cifre si "."'
            
        if self.__isNumber(year) == False:
            return 'Limita de predare trebuie sa contina doar cifre si "."'
        
        try:
            this = datetime.date(int(year), int(month), int(day))
        except ValueError:
            return "Limita de predare nu are numere corecte"
            
        return ""
        
class TestValidateProblem:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
    
    def test(self):
        """Test ValidateProblem class.
        """
        self.__testInit()
        
        self.__testIsNumber()
        
        self.__testValidateIdentification()
        self.__testValidateDescription()
        self.__testValidateTimeLimit()
        
        self.__testValidate()
        
    def __testInit(self):
        """Test ValidateProblem __init__ function.
        """
        assert True
        
    def __testIsNumber(self):
        """Test ValidateProblem __isNumber function.
        """
        testThis = ValidateProblem()
        assert testThis._ValidateProblem__isNumber("1") == True
        assert testThis._ValidateProblem__isNumber("1420") == True
        assert testThis._ValidateProblem__isNumber("0") == True
        assert testThis._ValidateProblem__isNumber("942") == True
        assert testThis._ValidateProblem__isNumber("a") == False
        assert testThis._ValidateProblem__isNumber("-1") == False
        assert testThis._ValidateProblem__isNumber("w110") == False
        assert testThis._ValidateProblem__isNumber("notNumber") == False
    
    def __testValidateIdentification(self):
        """Test ValidateProblem __validateIdentification function.
        """
        testThis = ValidateProblem()
        error1 = "Legitimatia nu are forma ceruta"
        error2 = 'Legitimatia trebuie sa contina doar cifre si "_"'
        
        problem = Problem("10 100", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == error1
        problem = Problem("a e", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == error1
        problem = Problem("error 1", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == error1
        problem = Problem("", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == error1
        problem = Problem("10 wzkj w", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == error1
        
        problem = Problem("10_10 ", "", "")
        testThis._ValidateProblem__validateIdentification(problem) == error2
        problem = Problem("1254s_10", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == error2
        problem = Problem("a_b", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == error2
        problem = Problem("___", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == error2
        problem = Problem("52_34_", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == error2
        
        problem = Problem("1_1", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == ""
        problem = Problem("10_43", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == ""
        problem = Problem("152_30", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == ""
        problem = Problem("4_5", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == ""
        problem = Problem("1000_143", "", "")
        assert testThis._ValidateProblem__validateIdentification(problem) == ""
    
    def __testValidateDescription(self):
        """Test ValidateProblem _validateDescription function.
        """
        testThis = ValidateProblem()
        
        problem = Problem("", "description", "")
        assert testThis._ValidateProblem__validateDescription(problem) == ""
        problem = Problem("", "newDescription", "")
        assert testThis._ValidateProblem__validateDescription(problem) == ""
        problem = Problem("", "description with numbers 12345", "")
        assert testThis._ValidateProblem__validateDescription(problem) == ""
        problem = Problem("", "10 11 100 1111", "")
        assert testThis._ValidateProblem__validateDescription(problem) == ""
        problem = Problem("", "", "")
        assert testThis._ValidateProblem__validateDescription(problem) == "Descrierea trebuie sa nu lipseasca"
    
    def __testValidateTimeLimit(self):
        """Test ValidateProblem _validateTimeLimit function.
        """
        testThis = ValidateProblem()
        error1 = "Limita de predare nu are forma ceruta"
        error2 = 'Limita de predare trebuie sa contina doar cifre si "."'
        error3 = "Limita de predare nu are numere corecte"
        
        problem = Problem("", "", "11 11 2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error1
        problem = Problem("", "", "not numbers")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error1
        problem = Problem("", "", "11.11.2023.")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error1
        problem = Problem("", "", ".20.012000")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error1
        # problem = Problem("", "", "10.07")
        # assert testThis._ValidateProblem__validateTimeLimit(problem) == error1
        
        problem = Problem("", "", "11a.11.2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error2
        problem = Problem("", "", "11.10.2023z")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error2
        problem = Problem("", "", "eleven.09.2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error2
        problem = Problem("", "", "-20.01.2000")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error2
        problem = Problem("", "", "notNumber.notNumber.notNumber")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error2
        
        problem = Problem("", "", "131.11.2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error3
        problem = Problem("", "", "11.1000.2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error3
        problem = Problem("", "", "100.42.2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error3
        problem = Problem("", "", "20.23.2000")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error3
        problem = Problem("", "", "40.07.2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == error3
        
        problem = Problem("", "", "11.11.2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == ""
        problem = Problem("", "", "11.10.2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == ""
        problem = Problem("", "", "11.09.2023")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == ""
        problem = Problem("", "", "20.01.2000")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == ""
        problem = Problem("", "", "10.07.2010")
        assert testThis._ValidateProblem__validateTimeLimit(problem) == ""
    
    def __testValidate(self):
        """Test ValidateProblem validate function.
        """
        testThis = ValidateProblem()
        
        problem = Problem("5_23", "se citesc doua numere; sa fie scrisa suma lor", "11.11.2023")
        try:
            testThis.validate(problem)
            assert True
        except ValidateException:
            assert False
        
        problem = Problem("5 23", "se citesc doua numere; sa fie scrisa suma lor", "11 11 2023")
        try:
            testThis.validate(problem)
            assert False
        except ValidateException:
            assert True
    
a = TestValidateProblem()
a.test()