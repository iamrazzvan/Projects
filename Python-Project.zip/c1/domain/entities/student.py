class Student:

    def __init__(self, identification: str, name: str, group: str):
        """Creates new student using the given identification, name and group.
        
        identification: str
        name: str
        group: str
        """
        self.newIdentification(identification)
        self.newName(name)
        self.newGroup(group)
    
    def newIdentification(self, identification: str):
        """Gives a new identification.
        """
        self.__identification = identification
        
    def newName(self, name: str):
        """Gives a new name.
        """
        self.__name = name
        
    def newGroup(self, group: str):
        """Gives a new group.
        """
        self.__group = group
    
    def returnIdentification(self) -> str:
        """Returns identification information.
        
        return: str
        """
        return self.__identification
        
    def returnName(self) -> str:
        """Returns name.
        
        return: str
        """
        return self.__name
        
    def returnFamilyName(self) -> str:
        """Returns family name.
        
        return: str
        """
        fragments = self.__name.partition(' ')
        return fragments[0]
        
    def returnNotFamilyName(self) -> str:
        """Returns not family name.
        
        return: str
        """
        fragments = self.__name.partition(' ')
        return fragments[2]
        
    def returnGroup(self) -> str:
        """Returns group.
        
        return: str
        """
        return self.__group
        
class TestStudent:

    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
    
    def test(self):
        """Tests student class.
        """
        self.__testNewIdentification()
        self.__testNewName()
        self.__testNewGroup()
        
        self.__testReturnIdentification()
        self.__testReturnName()
        self.__testReturnGroup()
        
        self.__testReturnFamilyName()
        self.__testReturnNotFamilyName()
        
        self.__testStudentInit()
    
    def __testStudentInit(self):
        """Tests student __init__ function.
        """
        testThis = Student("1", "Name Name", "Group53")
        assert testThis.returnIdentification() == "1"
        assert testThis.returnName() == "Name Name"
        assert testThis.returnGroup() == "Group53"
        
    def __testNewIdentification(self):
        """Test student newIdentification function.
        """
        testThis = Student("1", "Name Name", "Group53")
        testThis.newIdentification("newIdentification500")
        assert testThis._Student__identification == "newIdentification500"
        
    def __testNewName(self):
        """Test student newName function.
        """
        testThis = Student("1", "Name Name", "Group53")
        testThis.newName("newName newName")
        assert testThis._Student__name == "newName newName"
        
    def __testNewGroup(self):
        """Test student newGroup function.
        """
        testThis = Student("1", "Name Name", "Group53")
        testThis.newGroup("newGroup")
        assert testThis._Student__group == "newGroup"
        
    def __testReturnIdentification(self):
        """Test student returnIdentification function.
        """
        testThis = Student("1", "Name Name", "Group53")
        testThis._Student__identification = "newIdentification500"
        assert testThis.returnIdentification() == "newIdentification500"
        
    def __testReturnName(self):
        """Test student returnName function.
        """
        testThis = Student("1", "Name Name", "Group53")
        testThis._Student__name = "newName newName"
        assert testThis.returnName() == "newName newName"
       
    def __testReturnGroup(self):
        """Test student returnGroup function.
        """
        testThis = Student("1", "Name Name", "Group53")
        testThis._Student__group = "newGroup"
        assert testThis.returnGroup() == "newGroup"
        
    def __testReturnFamilyName(self):
        """Test student returnFamilyName function.
        """
        testThis = Student("1", "Name Name", "Group53")
        testThis._Student__name = "Family Name"
        assert testThis.returnFamilyName() == "Family"
        
    def __testReturnNotFamilyName(self):
        """Test student returnNotFamilyName function.
        """
        testThis = Student("1", "Name Name", "Group53")
        testThis._Student__name = "Family Name"
        assert testThis.returnNotFamilyName() == "Name"
        
a = TestStudent()
a.test()