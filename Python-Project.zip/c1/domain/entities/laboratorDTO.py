class LaboratorDTO:
    
    def __init__(self, lI: str, sI: str, sN: str, grade: int):
        """Function that gets called when creating a new LaboratorDTO Object.
        
        lI = laboratorIdentification
        sI = studentIdentification
        sN = studentName
        
        lI: str
        sI: str
        sN: str
        grade: int
        """
        
        self.__newLI(lI)
        self.__newSI(sI)
        self.__newSN(sN)
        self.__newGrade(grade)
        
    def __newLI(self, lI: str):
        """Set new value for laboratorIdentification.
        
        lI = laboratorIdentification
        
        lI: str
        """
        
        self.__laboratorIdentification = lI
        
    def __newSI(self, sI: str):
        """Set new value for studentIdentification.
        
        sI = studentIdentification
        
        sI: str
        """
        
        self.__studentIdentification = sI
        
    def __newSN(self, sN: str):
        """Set new value for studentName.
        
        sN = studentName
        
        sN: str
        """
        
        self.__studentName = sN
    
    def __newGrade(self, grade: int):
        """Set new value for grade.
        
        grade: int
        """
        
        self.__grade = grade
        
    def returnLI(self):
        """Return value for laboratorIdentification.
        
        return: str
        """
        
        return self.__laboratorIdentification
    
    def returnSI(self):
        """Return value for studentIdentification.
        
        return: str
        """
        
        return self.__studentIdentification
    
    def returnSN(self):
        """Return value for studentName.
        
        return: str
        """
        
        return self.__studentName
    
    def returnNameNoSpace(self):
        """Return value for studentFamilyName.
        
        return: str
        """
        
        a = self.__studentName.split(" ")
        return a[0] + a[1]
    
    def returnGrade(self):
        """Return value for grade.
        
        return: int
        """
        
        return self.__grade
        
class TestLaboratorDTO:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
        
    def test(self):
        """Test LaboratorDTO class.
        """
        
        self.__testInit()
        
        self.__testNewLI()
        self.__testNewSI()
        self.__testNewSN()
        self.__testNewGrade()
        
        self.__testReturnLI()
        self.__testReturnSI()
        self.__testReturnSN()
        self.__testReturnNameNoSpace()
        self.__testReturnGrade()
        
    def __testInit(self):
        """Test LaboratorDTO __init__ function.
        """
        
        assert True
        
    def __testNewLI(self):
        """Test LaboratorDTO __newLI function.
        """
        
        testThis = LaboratorDTO("1", "2", "Nume Prenume", 10)
        testThis._LaboratorDTO__newLI("3")
        assert testThis._LaboratorDTO__laboratorIdentification == "3"
        
    def __testNewSI(self):
        """Test LaboratorDTO __newSI function.
        """
        
        testThis = LaboratorDTO("1", "2", "Nume Prenume", 10)
        testThis._LaboratorDTO__newSI("3")
        assert testThis._LaboratorDTO__studentIdentification == "3"
        
    def __testNewSN(self):
        """Test LaboratorDTO __newSN function.
        """
        
        testThis = LaboratorDTO("1", "2", "Nume Prenume", 10)
        testThis._LaboratorDTO__newSN("altNume altNume")
        assert testThis._LaboratorDTO__studentName == "altNume altNume"
        
    def __testNewGrade(self):
        """Test LaboratorDTO __newGrade function.
        """
        
        testThis = LaboratorDTO("1", "2", "Nume Prenume", 10)
        testThis._LaboratorDTO__newGrade(9)
        assert testThis._LaboratorDTO__grade == 9
        
    def __testReturnLI(self):
        """Test LaboratorDTO returnLI function.
        """
        
        testThis = LaboratorDTO("1", "2", "Nume Prenume", 10)
        assert testThis.returnLI() == "1"
    
    def __testReturnSI(self):
        """Test LaboratorDTO returnSI function.
        """
        
        testThis = LaboratorDTO("1", "2", "Nume Prenume", 10)
        assert testThis.returnSI() == "2"
        
    def __testReturnSN(self):
        """Test LaboratorDTO returnSN function.
        """
        
        testThis = LaboratorDTO("1", "2", "Nume Prenume", 10)
        assert testThis.returnSN() == "Nume Prenume"
    
    def __testReturnNameNoSpace(self):
        """Test LaboratorDTO returnNameNoSpace function.
        """
        
        testThis = LaboratorDTO("1", "2", "Nume Prenume", 10)
        assert testThis.returnNameNoSpace() == "NumePrenume"
        
    def __testReturnGrade(self):
        """Test LaboratorDTO returnGrade function.
        """
        
        testThis = LaboratorDTO("1", "2", "Nume Prenume", 10)
        assert testThis.returnGrade() == 10
    
a = TestLaboratorDTO()
a.test()