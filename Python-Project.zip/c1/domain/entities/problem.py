class Problem:

    def __init__(self, identification: str, description: str, timeLimit: str):
        """Creates new problem using the given identification, description and timeLimit.
        
        identification: str
        description: str
        timeLimit: str
        """
        self.newIdentification(identification)
        self.newDescription(description)
        self.newTimeLimit(timeLimit)
        
    def newIdentification(self, identification: str):
        """Gives a new identification.
        """
        self.__identification = identification
        
    def newDescription(self, description: str):
        """Gives a new description.
        """
        self.__description = description
        
    def newTimeLimit(self, timeLimit: str):
        """Gives a new timeLimit.
        """
        self.__timeLimit = timeLimit
        
    def returnIdentification(self) -> str:
        """Returns identification information.
        
        return: str
        """
        return self.__identification
        
    def returnDescription(self) -> str:
        """Returns description information.
        
        return: str
        """
        return self.__description
        
    def returnTimeLimit(self) -> str:
        """Returns time limit information.
        
        return: str
        """
        return self.__timeLimit
        
class TestProblem:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def test(self):
        """Tests problem class.
        """
        self.__testNewIdentification()
        self.__testNewDescription()
        self.__testNewTimeLimit()
        
        self.__testReturnIdentification()
        self.__testReturnDescription()
        self.__testReturnTimeLimit()
        
        self.__testProblemInit()
        
    def __testProblemInit(self):
        """Tests problem __init__ function.
        """
        testThis = Problem("1", "se dau doua numere; sa fie scrisa suma lor", "11.11.2023")
        assert testThis.returnIdentification() == "1"
        assert testThis.returnDescription() == "se dau doua numere; sa fie scrisa suma lor"
        assert testThis.returnTimeLimit() == "11.11.2023"
        
    def __testNewIdentification(self):
        """tests problem newIdentification function.
        """
        testThis = Problem("1", "se dau doua numere; sa fie scrisa suma lor", "11.11.2023")
        testThis.newIdentification("newIdentification")
        assert testThis._Problem__identification == "newIdentification"
        
    def __testNewDescription(self):
        """tests problem newDescription function.
        """
        testThis = Problem("1", "se dau doua numere; sa fie scrisa suma lor", "11.11.2023")
        testThis.newDescription("newDescription")
        assert testThis._Problem__description == "newDescription"
        
    def __testNewTimeLimit(self):
        """tests problem newTimeLimit function.
        """
        testThis = Problem("1", "se dau doua numere; sa fie scrisa suma lor", "11.11.2023")
        testThis.newTimeLimit("11.11.2024")
        assert testThis._Problem__timeLimit == "11.11.2024"
        
    def __testReturnIdentification(self):
        """tests problem returnIdentification function.
        """
        testThis = Problem("1", "se dau doua numere; sa fie scrisa suma lor", "11.11.2023")
        testThis._Problem__identification = "newIdentification"
        assert testThis.returnIdentification() == "newIdentification"
        
    def __testReturnDescription(self):
        """tests problem returnDescription function.
        """
        testThis = Problem("1", "se dau doua numere; sa fie scrisa suma lor", "11.11.2023")
        testThis._Problem__description = "newDescription"
        assert testThis.returnDescription() == "newDescription"
        
    def __testReturnTimeLimit(self):
        """tests problem returnTimeLimit function.
        """
        testThis = Problem("1", "se dau doua numere; sa fie scrisa suma lor", "11.11.2023")
        testThis._Problem__timeLimit = "11.11.2024"
        assert testThis.returnTimeLimit() == "11.11.2024"
        
a = TestProblem()
a.test()