class Laborator:
    
    def __init__(self, laboratorIdentification: str, studentIdentification: str, problemIdentification: str):
        """Creates new laborator assigment using the given
        studentIdentification and problemIdentification.
        
        studentIdentification: str
        problemIdentification: str
        """
        self.newLaboratorIdentification(laboratorIdentification)
        self.newStudentIdentification(studentIdentification)
        self.newProblemIdentification(problemIdentification)
        self.newGrade(-1)
        
    def newLaboratorIdentification(self, laboratorIdentification: str):
        """Gives a new laborator identeification.
        
        laboratorIdentification: str
        """
        self.__laboratorIdentification = laboratorIdentification
        
    def newStudentIdentification(self, studentIdentification: str):
        """Gives a new student identification.
        
        studentIdentification: str
        """
        self.__studentIdentification = studentIdentification
        
    def newProblemIdentification(self, problemIdentification: str):
        """Gives a new problem identification.
        
        problemIdentification: str
        """
        self.__problemIdentification = problemIdentification
        
    def newGrade(self, grade: int):
        """Gives a new grade.
        
        grade: int
        """
        self.__grade = grade
        
    def returnLaboratorIdentification(self) -> str:
        """Return laborator identification.
        
        return: str
        """
        return self.__laboratorIdentification
        
    def returnStudentIdentification(self) -> str:
        """Return student identification.
        
        return: str
        """
        return self.__studentIdentification
        
    def returnProblemIdentification(self) -> str:
        """Return problem identification.
        
        return: str
        """
        return self.__problemIdentification
    
    def returnGrade(self) -> int:
        """Return grade.
        
        return: int
        """
        return self.__grade
        
class TestLaborator:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def test(self):
        """Tests laborator class.
        """
        self.__testNewLaboratorIdentification()
        self.__testNewStudentIdentification()
        self.__testNewProblemIdentification()
        self.__testNewGrade()
        
        self.__testReturnLaboratorIdentification()
        self.__testReturnStudentIdentification()
        self.__testReturnProblemIdentification()
        self.__testReturnGrade()
        
        self.__testLaboratorInit()
        
    def __testLaboratorInit(self):
        """Test Laborator __init__ function.
        """
        testThis = Laborator("1", "3", "1_5")
        assert testThis.returnLaboratorIdentification() == "1"
        assert testThis.returnStudentIdentification() == "3"
        assert testThis.returnProblemIdentification() == "1_5"
        assert testThis.returnGrade() == -1
        
    def __testNewLaboratorIdentification(self):
        """Test Laborator newIdentification function.
        """
        testThis = Laborator("1", "3", "1_5")
        testThis.newLaboratorIdentification("4")
        assert testThis._Laborator__laboratorIdentification == "4"
        
    def __testNewStudentIdentification(self):
        """Test Laborator newStudentIdentification function.
        """
        testThis = Laborator("1", "3", "1_5")
        testThis.newStudentIdentification("4")
        assert testThis._Laborator__studentIdentification == "4"
        
    def __testNewProblemIdentification(self):
        """Test Laborator newProblemIdentification function.
        """
        testThis = Laborator("1", "3", "1_5")
        testThis.newProblemIdentification("1_4")
        assert testThis._Laborator__problemIdentification == "1_4"
        
    def __testNewGrade(self):
        """Test Laborator newGrade function.
        """
        testThis = Laborator("1", "3", "1_5")
        testThis.newGrade("10")
        assert testThis._Laborator__grade == "10"
        
    def __testReturnLaboratorIdentification(self):
        """Test Laborator returnLaboratorIdentification function.
        """
        testThis = Laborator("1", "3", "1_5")
        testThis._Laborator__laboratorIdentification = "4"
        assert testThis.returnLaboratorIdentification() == "4"
        
    def __testReturnStudentIdentification(self):
        """Test Laborator returnStudentIdentification function.
        """
        testThis = Laborator("1", "3", "1_5")
        testThis._Laborator__studentIdentification = "4"
        assert testThis.returnStudentIdentification() == "4"
        
    def __testReturnProblemIdentification(self):
        """Test Laborator returnProblemIdentification function.
        """
        testThis = Laborator("1", "3", "1_5")
        testThis._Laborator__problemIdentification = "1_4"
        assert testThis.returnProblemIdentification() == "1_4"
        
    def __testReturnGrade(self):
        """Test Laborator returnGrade function.
        """
        testThis = Laborator("1", "3", "1_5")
        testThis._Laborator__grade = "10"
        assert testThis.returnGrade() == "10"
        
a = TestLaborator()
a.test()