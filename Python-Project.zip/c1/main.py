from repository.file.student import RememberStudent
from repository.file.problem import RememberProblem
from repository.file.laborator import RememberLaborator
from domain.validate.validateStudent import ValidateStudent
from domain.validate.validateProblem import ValidateProblem
from domain.validate.validateLaborator import ValidateLaborator
from services.studentService import StudentService
from services.problemService import ProblemService
from services.laboratorService import LaboratorService
from ui.console import Console

studentRepository = RememberStudent("students.in")
studentValidate = ValidateStudent()
studentService = StudentService(studentRepository, studentValidate)

problemRepository = RememberProblem("problems.in")
problemValidate = ValidateProblem()
problemService = ProblemService(problemRepository, problemValidate)

laboratorRepository = RememberLaborator("laborators.in")
laboratorValidate = ValidateLaborator()
laboratorService = LaboratorService(laboratorRepository, laboratorValidate, studentRepository, problemRepository)

services = {}

services["student"] = studentService
services["problem"] = problemService
services["laborator"] = laboratorService

ui = Console(services)

ui.run()