from domain.entities.laborator import Laborator
from repository.memory.laborator import MemoryLaborator

class RememberLaborator(MemoryLaborator):
    
    def __init__(self, name: str):
        """Function that gets called when there is a new RememberLaborator object.
        
        name: str
        """
        
        MemoryLaborator.__init__(self)
        self.newName(name)
        self.__remember()
        
    def newName(self, name: str):
        """Create new name for the file where to save information.
        """
        
        self.__name = name
        
    def returnName(self):
        """Return the name of the file where the information is saved.
        """
        
        return self.__name
    
    def __save(self):
        """Save to file.
        """
        
        file = open(self.returnName(), "w")
        
        laborators = MemoryLaborator.returnAllLaborators(self)
        c = len(laborators)
        for i in laborators:
            lI = i.returnLaboratorIdentification()
            sI = i.returnStudentIdentification()
            pI = i.returnProblemIdentification()
            grade = str(i.returnGrade())
            a = (lI + ";" + sI + ";" + pI + ";" + grade).strip("\n")
            file.write(a)
            c -= 1
            if c > 0:
                file.write("\n")
        
        file.close()
        
    def __remember(self):
        """Remember from file.
        """
        
        file = open(self.returnName(), "r")
        
        for line in file:
            l = line.split(";")
            laborator = Laborator(l[0], l[1], l[2])
            laborator.newGrade(int(l[3]))
            MemoryLaborator.rememberLaborator(self, laborator)
    
        file.close()
    
    def searchLaborator(self, laboratorIdentification: str, studentIdentification: str):
        """Search laborator given for the laborator with number "laboratorIdentification"
        to the student with "studentIdentification" identification.
        
        Raise RepositoryException if no laborator is found.
        
        laboratorIdentification: str
        studentIdentification: str
        return: Laborator
        """
        
        return MemoryLaborator.searchLaborator(self, laboratorIdentification, studentIdentification)
        
    def rememberLaborator(self, laborator):
        """Remember in memory a laborator.
        
        Raises RepositoryException if a laborator
        already exists.
        
        laborator: Laborator
        """
        
        MemoryLaborator.rememberLaborator(self, laborator)
        self.__save()
        
    def updateLaborator(self, laboratorIdentification: str, studentIdentification: str, grade: int):
        """Update the grade for the laborator with the number "laboratorIdentification" for the
        student with the "studentIdentification" identification.
        
        laboratorIdentification: str
        studentIdentification: str
        grade: int
        """
        
        MemoryLaborator.updateLaborator(self, laboratorIdentification, studentIdentification, grade)
        self.__save()
       
    def returnAllLaborators(self):
        """Returns all laborators.
        """
        
        return MemoryLaborator.returnAllLaborators(self)
        
    def returnLaboratorForNumber(self, lI: str):
        """Returns all laborators with the number "lI"
        
        lI = laboratorIdentifiation
        
        lI: str
        """
        
        return MemoryLaborator.returnLaboratorForNumber(self, lI)
    
class TestRememberLaborator():
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
        
    def test(self):
        """Test RememberLaborator class.
        """
        
        self.__testInit()
        
        self.__testNewName()
        self.__testReturnName()
        
        self.__testSave()
        self.__testRemember()
        
        self.__testRememberLaborator()
        self.__testUpdateLaborator()
        self.__testSearchLaborator()
        
        self.__testReturnAllLaborators()
        self.__testReturnLaboratorForNumber()
        
        self.__clear()
        
    def __clear(self):
        """Clear the file.
        """
        file = open("testLaborators.in", "w")
        file.write("")
        file.close()
        
    def __testInit(self):
        """Test RememberLaborator __init__ function.
        """
        
        testThis = RememberLaborator("testLaborators.in")
        assert testThis.returnName() == "testLaborators.in"
        
    def __testNewName(self):
        """Test RememberLaborator newName function.
        """
        
        testThis = RememberLaborator("testLaborators.in")
        testThis.newName("newName.in")
        assert testThis._RememberLaborator__name == "newName.in"
        
    def __testReturnName(self):
        """Test RememberLaborator returName function.
        """
        
        testThis = RememberLaborator("testLaborators.in")
        testThis._RememberLaborator__name = "newName.in"
        assert testThis.returnName() == "newName.in"
        
    def __testSave(self):
        """Test RememberLaborator save function.
        """
        
        self.__clear()
        testThis = RememberLaborator("testLaborators.in")
        laborator = Laborator("2", "1", "2_43")
        testThis.rememberLaborator(laborator)
        testThis._RememberLaborator__save()
        file = open("testLaborators.in", "r")
        assert file.read() == "2;1;2_43;-1"
        file.close()
        
    def __testRemember(self):
        """Test RememberLaborator remember function.
        """
        
        testThis = RememberLaborator("testLaborators.in")
        try:
            laborator = testThis.searchLaborator("2", "1")
            assert laborator.returnLaboratorIdentification() == "2"
            assert laborator.returnStudentIdentification() == "1"
            assert laborator.returnProblemIdentification() == "2_43"
            assert laborator.returnGrade() == -1
        except:
            assert False
        
    def __testRememberLaborator(self):
        """Test RememberLaborator rememberLaborator function.
        """
        
        self.__clear()
        testThis = RememberLaborator("testLaborators.in")
        laborator = Laborator("2", "1", "2_43")
        testThis.rememberLaborator(laborator)
        testThis._RememberLaborator__save()
        file = open("testLaborators.in", "r")
        assert file.read() == "2;1;2_43;-1"
        file.close()
    
    def __testUpdateLaborator(self):
        """Test RememberLaborator updateLaborator function.
        """
        
        self.__clear()
        testThis = RememberLaborator("testLaborators.in")
        laborator = Laborator("2", "1", "2_43")
        testThis.rememberLaborator(laborator)
        testThis.updateLaborator("2", "1", 10)
        testThis._RememberLaborator__save()
        file = open("testLaborators.in", "r")
        assert file.read() == "2;1;2_43;10"
        file.close()
        
    def __testSearchLaborator(self):
        """Test RememberLaborator searchLaborator function.
        """
        
        self.__clear()
        testThis = RememberLaborator("testLaborators.in")
        laborator = Laborator("2", "1", "2_43")
        testThis.rememberLaborator(laborator)
        testThis._RememberLaborator__save()
        assert testThis.searchLaborator("2", "1") == laborator
        
    def __testRemoveLaborator(self):
        """Test RememberLaborator removeLaborator function.
        """
        
        self.__clear()
        testThis = RememberLaborator("testLaborators.in")
        laborator = Laborator("2", "1", "2_43")
        testThis.rememberLaborator(laborator)
        testThis._RememberLaborator__save()
        testThis.removeLaborator("1")
        testThis._RememberLaborator__save()
        try:
            testThis.searchLaborator("1")
            assert False
        except:
            assert True
        file = open("testLaborators.in", "r")
        assert file.read() == ""
        file.close()
        
    def __testReturnAllLaborators(self):
        """Test RememberLaborator returnAllLaborators function.
        """
        
        self.__clear()
        testThis = RememberLaborator("testLaborators.in")
        laborator = Laborator("2", "1", "2_43")
        testThis.rememberLaborator(laborator)
        assert testThis.returnAllLaborators() == [laborator]
        
    def __testReturnLaboratorForNumber(self):
        """Test RememberLaborator returnLaboratorForNumber function.
        """
        
        self.__clear()
        testThis = RememberLaborator("testLaborators.in")
        laborator1 = Laborator("2", "1", "2_43")
        testThis.rememberLaborator(laborator1)
        laborator2 = Laborator("3", "1", "3_800")
        testThis.rememberLaborator(laborator2)
        assert testThis.returnLaboratorForNumber("2") == [laborator1]
        
a = TestRememberLaborator()
a.test()