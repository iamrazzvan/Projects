from domain.entities.problem import Problem
from repository.memory.problem import MemoryProblem

class RememberProblem(MemoryProblem):
    
    def __init__(self, name: str):
        """Function that gets called when there is a new RememberProblem object.
        
        name: str
        """
        
        MemoryProblem.__init__(self)
        self.newName(name)
        self.__remember()
        
    def newName(self, name: str):
        """Create new name for the file where to save information.
        """
        
        self.__name = name
        
    def returnName(self):
        """Return the name of the file where the information is saved.
        """
        
        return self.__name
    
    def __save(self):
        """Save to file.
        """
        
        file = open(self.returnName(), "w")
        
        problems = MemoryProblem.returnAllProblems(self)
        c = len(problems)
        for i in problems:
            pI = i.returnIdentification()
            pD = i.returnDescription()
            pL = i.returnTimeLimit()
            a = (pI + ";" + pD + ";" + pL).strip("\n")
            file.write(a)
            c -= 1
            if c > 0:
                file.write("\n")
        
        file.close()
        
    def __remember(self):
        """Remember from file.
        """
        
        file = open(self.returnName(), "r")
        
        for line in file:
            p = line.split(";")
            problem = Problem(p[0], p[1], p[2])
            MemoryProblem.rememberProblem(self, problem)
        
        file.close()
    
    def rememberProblem(self, problem):
        """Remember in memory a problem.
        
        Raises RepositoryException if a problem
        with the same identification ifnromation exists already.
        
        problem: Problem
        """
        
        MemoryProblem.rememberProblem(self, problem)
        self.__save()

    def updateProblem(self, identification: str, problem):
        """Update in memory the problem with given identification.
        
        Raise RepositoryException if there is no problem with the given identification.
        
        identification: str
        problem: Problem
        """
        
        MemoryProblem.updateProblem(self, identification, problem)
        self.__save()
        
    def searchProblem(self, identification: str):
        """Search the problem with given identification from memory.
        
        Riase RepositoryException if no problem
        with the given identification exists.
        
        identification: str
        return: Problem
        """
        
        return MemoryProblem.searchProblem(self, identification)
        
    def removeProblem(self, identification: str):
        """Removes the problem with given identification from memory.
        
        Raises RepositoryException if no problem
        with the given identification exists.
        
        identification: str
        """
        
        MemoryProblem.removeProblem(self, identification)
        self.__save()
        
class TestRememberProblem():
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
        
    def test(self):
        """Test RememberProblem class.
        """
        
        self.__testInit()
        
        self.__testNewName()
        self.__testReturnName()
        
        self.__testSave()
        self.__testRemember()
        
        self.__testRememberProblem()
        self.__testUpdateProblem()
        self.__testSearchProblem()
        self.__testRemoveProblem()
        
        self.__clear()
        
    def __clear(self):
        """Clear the file.
        """
        file = open("testProblems.in", "w")
        file.write("")
        file.close()
        
    def __testInit(self):
        """Test RememberProblem __init__ function.
        """
        
        testThis = RememberProblem("testProblems.in")
        assert testThis.returnName() == "testProblems.in"
        
    def __testNewName(self):
        """Test RememberProblem newName function.
        """
        
        testThis = RememberProblem("testProblems.in")
        testThis.newName("newName.in")
        assert testThis._RememberProblem__name == "newName.in"
        
    def __testReturnName(self):
        """Test RememberProblem returName function.
        """
        
        testThis = RememberProblem("testProblems.in")
        testThis._RememberProblem__name = "newName.in"
        assert testThis.returnName() == "newName.in"
        
    def __testSave(self):
        """Test RememberProblem save function.
        """
        
        self.__clear()
        testThis = RememberProblem("testProblems.in")
        problem = Problem("1", "write a number on screen", "11.11.2023")
        testThis.rememberProblem(problem)
        testThis._RememberProblem__save()
        file = open("testProblems.in", "r")
        assert file.read() == "1;write a number on screen;11.11.2023"
        file.close()
        
    def __testRemember(self):
        """Test RememberProblem remember function.
        """
        
        testThis = RememberProblem("testProblems.in")
        try:
            problem = testThis.searchProblem("1")
            assert problem.returnIdentification() == "1"
            assert problem.returnDescription() == "write a number on screen"
            assert problem.returnTimeLimit() == "11.11.2023"
        except:
            assert False
        
    def __testRememberProblem(self):
        """Test RememberProblem rememberProblem function.
        """
        
        self.__clear()
        testThis = RememberProblem("testProblems.in")
        problem = Problem("1", "write a number on screen", "11.11.2023")
        testThis.rememberProblem(problem)
        testThis._RememberProblem__save()
        file = open("testProblems.in", "r")
        assert file.read() == "1;write a number on screen;11.11.2023"
        file.close()
    
    def __testUpdateProblem(self):
        """Test RememberProblem updateProblem function.
        """
        
        self.__clear()
        testThis = RememberProblem("testProblems.in")
        problem = Problem("1", "write a number on screen", "11.11.2023")
        testThis.rememberProblem(problem)
        newProblem = Problem("1", "new", "20.11.2023")
        testThis.updateProblem("1", newProblem)
        testThis._RememberProblem__save()
        file = open("testProblems.in", "r")
        assert file.read() == "1;new;20.11.2023"
        file.close()
        
    def __testSearchProblem(self):
        """Test RememberProblem searchProblem function.
        """
        
        self.__clear()
        testThis = RememberProblem("testProblems.in")
        problem = Problem("1", "write a number on screen", "11.11.2023")
        testThis.rememberProblem(problem)
        testThis._RememberProblem__save()
        assert testThis.searchProblem("1") == problem
        
    def __testRemoveProblem(self):
        """Test RememberProblem removeProblem function.
        """
        
        self.__clear()
        testThis = RememberProblem("testProblems.in")
        problem = Problem("1", "write a number on screen", "11.11.2023")
        testThis.rememberProblem(problem)
        testThis._RememberProblem__save()
        testThis.removeProblem("1")
        testThis._RememberProblem__save()
        try:
            testThis.searchProblem("1")
            assert False
        except:
            assert True
        file = open("testProblems.in", "r")
        assert file.read() == ""
        file.close()
        
a = TestRememberProblem()
a.test()