from domain.entities.student import Student
from repository.memory.student import MemoryStudent

class RememberStudent(MemoryStudent):
    
    def __init__(self, name: str):
        """Function that gets called when there is a new RememberStudent object.
        
        name: str
        """
        
        MemoryStudent.__init__(self)
        self.newName(name)
        self.__remember()
        
    def newName(self, name: str):
        """Create new name for the file where to save information.
        """
        
        self.__name = name
        
    def returnName(self):
        """Return the name of the file where the information is saved.
        """
        
        return self.__name
    
    def __save(self):
        """Save to file.
        """
        
        file = open(self.returnName(), "w")
        
        students = MemoryStudent.returnAllStudents(self)
        c = len(students)
        for i in students:
            sI = i.returnIdentification()
            sN = i.returnName()
            sG = i.returnGroup()
            a = (sI + ";" + sN + ";" + sG).strip("\n")
            file.write(a)
            c -= 1
            if c > 0:
                file.write("\n")
        
        file.close()
        
    def __remember(self):
        """Remember from file.
        """
        
        file = open(self.returnName(), "r")
        
        for line in file:
            s = line.split(";")
            student = Student(s[0], s[1], s[2])
            MemoryStudent.rememberStudent(self, student)
        
        file.close()
        
    def rememberStudent(self, student):
        """Remember in file a student.
        
        Raises RepositoryException if a student
        with the same identification information exists already.
        
        student: Student
        """
        
        MemoryStudent.rememberStudent(self, student)
        self.__save()
        
    def updateStudent(self, identification: str, student):
        """Update in memory the student with given identification.
        
        Raise RepositoryException if there is no student with the given identification.
        
        identification: str
        student: Student
        """
        
        MemoryStudent.updateStudent(self, identification, student)
        self.__save()
    
    def searchStudent(self, identification: str):
        """Search the student with given identification from memory.
        
        Raise RepositoryException if no student
        with the given information exists.
        
        identification: str
        return: Student
        """
        
        return MemoryStudent.searchStudent(self, identification)
    
    def removeStudent(self, identification: str):
        """Removes the student with given identification from memory.
        
        Raises RepositoryException if no student
        with the given identification exists.
        
        identification: str
        """
        
        MemoryStudent.removeStudent(self, identification)
        self.__save()
        
class TestRememberStudent():
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
        
    def test(self):
        """Test RememberStudent class.
        """
        
        self.__testInit()
        
        self.__testNewName()
        self.__testReturnName()
        
        self.__testSave()
        self.__testRemember()
        
        self.__testRememberStudent()
        self.__testUpdateStudent()
        self.__testSearchStudent()
        self.__testRemoveStudent()
        
        self.__clear()
        
    def __clear(self):
        """Clear the file.
        """
        file = open("testStudents.in", "w")
        file.write("")
        file.close()
        
    def __testInit(self):
        """Test RememberStudent __init__ function.
        """
        
        testThis = RememberStudent("testStudents.in")
        assert testThis.returnName() == "testStudents.in"
        
    def __testNewName(self):
        """Test RememberStudent newName function.
        """
        
        testThis = RememberStudent("testStudents.in")
        testThis.newName("newName.in")
        assert testThis._RememberStudent__name == "newName.in"
        
    def __testReturnName(self):
        """Test RememberStudent returName function.
        """
        
        testThis = RememberStudent("testStudents.in")
        testThis._RememberStudent__name = "newName.in"
        assert testThis.returnName() == "newName.in"
        
    def __testSave(self):
        """Test RememberStudent save function.
        """
        
        self.__clear()
        testThis = RememberStudent("testStudents.in")
        student = Student("1", "Nume Prenume", "1")
        testThis.rememberStudent(student)
        testThis._RememberStudent__save()
        file = open("testStudents.in", "r")
        assert file.read() == "1;Nume Prenume;1"
        file.close()
        
    def __testRemember(self):
        """Test RememberStudent remember function.
        """
        
        testThis = RememberStudent("testStudents.in")
        try:
            student = testThis.searchStudent("1")
            assert student.returnIdentification() == "1"
            assert student.returnName() == "Nume Prenume"
            assert student.returnGroup() == "1"
        except:
            assert False
        
    def __testRememberStudent(self):
        """Test RememberStudent rememberStudent function.
        """
        
        self.__clear()
        testThis = RememberStudent("testStudents.in")
        student = Student("1", "Nume Prenume", "1")
        testThis.rememberStudent(student)
        testThis._RememberStudent__save()
        file = open("testStudents.in", "r")
        assert file.read() == "1;Nume Prenume;1"
        file.close()
    
    def __testUpdateStudent(self):
        """Test RememberStudent updateStudent function.
        """
        
        self.__clear()
        testThis = RememberStudent("testStudents.in")
        student = Student("1", "Nume Prenume", "1")
        testThis.rememberStudent(student)
        newStudent = Student("1", "Name Name", "40")
        testThis.updateStudent("1", newStudent)
        testThis._RememberStudent__save()
        file = open("testStudents.in", "r")
        assert file.read() == "1;Name Name;40"
        file.close()
        
    def __testSearchStudent(self):
        """Test RememberStudent searchStudent function.
        """
        
        self.__clear()
        testThis = RememberStudent("testStudents.in")
        student = Student("1", "Nume Prenume", "1")
        testThis.rememberStudent(student)
        testThis._RememberStudent__save()
        assert testThis.searchStudent("1") == student
        
    def __testRemoveStudent(self):
        """Test RememberStudent removeStudent function.
        """
        
        self.__clear()
        testThis = RememberStudent("testStudents.in")
        student = Student("1", "Nume Prenume", "1")
        testThis.rememberStudent(student)
        testThis._RememberStudent__save()
        testThis.removeStudent("1")
        testThis._RememberStudent__save()
        try:
            testThis.searchStudent("1")
            assert False
        except:
            assert True
        file = open("testStudents.in", "r")
        assert file.read() == ""
        file.close()
        
a = TestRememberStudent()
a.test()