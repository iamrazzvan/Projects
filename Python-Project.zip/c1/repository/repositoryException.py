class RepositoryException(Exception):
    
    def __init__(self, errors: str):
        """Creates new RepositoryException using the given errors.
        
        errors: str
        """
        self.newErrors(errors)
        
    def newErrors(self, errors: str):
        """Gives new errors.
        """
        self.__errors = errors
            
    def returnErrors(self) -> str:
        """Returns errors.
        
        return: str
        """
        return self.__errors

class TestRepositoryException():
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def test(self):
        """Test RepositoryException class.
        """
        
        self.__testNewErrors()
        
        self.__testReturnErrors()
        
        self.__testInit()
        
    def __testNewErrors(self):
        """Test RepositoryException newErrors function.
        """
        testThis = RepositoryException("errors")
        testThis.newErrors("newErrors")
        assert testThis._RepositoryException__errors == "newErrors"
        
    def __testReturnErrors(self):
        """Test RepositoryException returnErrors function.
        """
        testThis = RepositoryException("errors")
        testThis._RepositoryException__errors = "newErrors"
        assert testThis.returnErrors() == "newErrors"
        
    def __testInit(self):
        """Test RepositoryException __init__ function.
        """
        testThis = RepositoryException("errors")
        assert testThis.returnErrors() == "errors"
        
a = TestRepositoryException()
a.test()