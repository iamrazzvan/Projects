from domain.entities.problem import Problem
from repository.repositoryException import RepositoryException

class MemoryProblem:

    def __init__(self):
        """Creates new dictionary of problems.
        """
        
        self.__problems = {}

    def rememberProblem(self, problem):
        """Remember in memory a problem.
        
        Raises RepositoryException if a problem
        with the same identification ifnromation exists already.
        
        problem: Problem
        """
        
        identification = problem.returnIdentification()
        
        if identification in self.__problems:
            raise RepositoryException("Legitimatia deja exista")
            
        self.__problems[identification] = problem

    def updateProblem(self, identification: str, problem):
        """Update in memory the problem with given identification.
        
        Raise RepositoryException if there is no problem with the given identification.
        
        identification: str
        problem: Problem
        """
        if identification == problem.returnIdentification():
            self.removeProblem(identification)
            self.rememberProblem(problem)
        else:
            self.rememberProblem(problem)
            self.removeProblem(identification)

    def searchProblem(self, identification: str):
        """Search the problem with given identification from memory.
        
        Riase RepositoryException if no problem
        with the given identification exists.
        
        identification: str
        return: Problem
        """
        
        if identification not in self.__problems:
            raise RepositoryException("Legitimatia nu exista")
            
        return self.__problems[identification]
        
    def removeProblem(self, identification: str):
        """Removes the problem with given identification from memory.
        
        Raises RepositoryException if no problem
        with the given identification exists.
        
        identification: str
        """
        
        if identification not in self.__problems:
            raise RepositoryException("Legitimatia nu exista")
            
        del self.__problems[identification]
    
    def returnAllProblems(self):
        """Returns all problems.
        """
        
        return list(self.__problems.values())
        
class TestMemoryProblem:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def test(self):
        """Test MemoryProblem class.
        """
        
        self.__testInit()
        
        self.__testRememberProblem()
        self.__testUpdateProblem()
        self.__testSearchProblem()
        self.__testRemoveProblem()
        self.__testReturnAllProblems()
        
    def __testInit(self):
        """Test MemoryProblem __init__ function.
        """
        assert True
        
    def __testRememberProblem(self):
        """Test MemoryProblem rememberProblem function.
        """
        testThis = MemoryProblem()
        problem = Problem("1_40", "", "")
        
        try:
            testThis.rememberProblem(problem)
            assert True
        except RepositoryException:
            assert False
        
        try:
            testThis.rememberProblem(problem)
            assert False
        except RepositoryException:
            assert True
    
    def __testUpdateProblem(self):
        """Test MemoryProblem updateProblem function.
        """
        testThis = MemoryProblem()
        
        firstProblem = Problem("3_43", "Description", "11.11.2023")
        testThis.rememberProblem(firstProblem)
        
        anotherProblem = Problem("3_53", "newDescription", "20.11.2023")
        testThis.updateProblem("3_43", anotherProblem)
        
        try:
        
            newProblem = testThis.searchProblem("3_53")
            assert newProblem.returnIdentification() == "3_53"
            assert newProblem.returnDescription() == "newDescription"
            assert newProblem.returnTimeLimit() == "20.11.2023"
            
            try:
                problem = testThis.searchProblem("3_43")
                assert False
            except RepositoryException:
                assert True
            
        except RepositoryException:
            
            assert False
    
    def __testSearchProblem(self):
        """Test MemoryProblem searchProblem function.
        """
        testThis = MemoryProblem()
        
        try:
            testThis.searchProblem("1_40")
            assert False
        except RepositoryException:
            assert True
        
        problem = Problem("1_40", "", "")
        testThis.rememberProblem(problem)
        
        try:
            testThis.searchProblem("1_40")
            assert True
        except RepositoryException:
            assert False
    
    def __testRemoveProblem(self):
        """Test MemoryProblem removeProblem function.
        """
        testThis = MemoryProblem()
        
        try:
            testThis.removeProblem("1_40")
            assert False
        except RepositoryException:
            assert True
        
        problem = Problem("1_40", "", "")
        testThis.rememberProblem(problem)
        
        try:
            testThis.removeProblem("1_40")
            assert True
        except RepositoryException:
            assert False
            
    def __testReturnAllProblems(self):
        """Test MemoryProblem returnAllProblems function.
        """
        
        testThis = MemoryProblem()
        problem1 = Problem("1_1", "Write a number on screen", "11.11.2023")
        problem2 = Problem("3_5", "Write two numbers on screen", "11.11.2023")
        testThis.rememberProblem(problem1)
        testThis.rememberProblem(problem2)
        
        l = testThis.returnAllProblems()
        l2 = [problem1, problem2]
        
        for i in range(2):
            assert l[i].returnIdentification() == l2[i].returnIdentification()
            assert l[i].returnDescription() == l2[i].returnDescription()
            assert l[i].returnTimeLimit() == l2[i].returnTimeLimit()
        
a = TestMemoryProblem()
a.test()