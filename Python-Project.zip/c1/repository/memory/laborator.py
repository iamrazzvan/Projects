from domain.entities.laborator import Laborator
from repository.repositoryException import RepositoryException

class MemoryLaborator:
    
    def __init__(self):
        """Creates a new dictionary of laborators.
        """
        
        self.__laborators = {}
        
    def searchLaborator(self, laboratorIdentification: str, studentIdentification: str):
        """Search laborator given for the laborator with number "laboratorIdentification"
        to the student with "studentIdentification" identification.
        
        Raise RepositoryException if no laborator is found.
        
        laboratorIdentification: str
        studentIdentification: str
        return: Laborator
        """
        
        memoryLaboratorIdentification = laboratorIdentification + "__" + studentIdentification
        
        if memoryLaboratorIdentification not in self.__laborators:
            raise RepositoryException("Laboratorul nu exista")
            
        return self.__laborators[memoryLaboratorIdentification]
        
    def rememberLaborator(self, laborator):
        """Remember in memory a laborator.
        
        Raises RepositoryException if a laborator
        already exists.
        
        laborator: Laborator
        """
        
        laboratorIdentification = laborator.returnLaboratorIdentification()
        studentIdentification = laborator.returnStudentIdentification()
        memoryLaboratorIdentification = laboratorIdentification + "__" + studentIdentification
        
        if memoryLaboratorIdentification in self.__laborators:
            raise RepositoryException("Atribuirea laborator student exista deja")
        
        self.__laborators[memoryLaboratorIdentification] = laborator
        
    def updateLaborator(self, laboratorIdentification: str, studentIdentification: str, grade: int):
        """Update the grade for the laborator with the number "laboratorIdentification" for the
        student with the "studentIdentification" identification.
        
        laboratorIdentification: str
        studentIdentification: str
        grade: int
        """
        
        laborator = self.searchLaborator(laboratorIdentification, studentIdentification)
        
        if laborator.returnGrade() != -1:
            raise RepositoryException("Laboratorul are deja o nota adaugata")
        
        laborator.newGrade(grade)
       
    def returnAllLaborators(self):
        """Returns all laborators.
        """
        
        return list(self.__laborators.values())
        
    def returnLaboratorForNumber(self, lI: str):
        """Returns all laborators with the number "lI"
        
        lI = laboratorIdentifiation
        
        lI: str
        """
        
        l = []
        laborators = self.returnAllLaborators()
        
        for laborator in laborators:
            number = laborator.returnLaboratorIdentification()
            numbers = number.split("_")
            if numbers[0] == lI:
                l.append(laborator)
       
        return l
       
class TestMemoryLaborator:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = "")
    
    def test(self):
        """Test MemoryLaborator class.
        """
        
        self.__testInit()
        
        self.__testSearchLaborator()
        self.__testRememberLaborator()
        self.__testUpdateLaborator()
        self.__testReturnAllLaborators()
        self.__testReturnLaboratorForNumber()
        
    def __testInit(self):
        """Test MemoryLaborator __init__ function.
        """
        assert True
        
    def __testSearchLaborator(self):
        """Test MemoryLaborator searchLaborator function.
        """
        
        testThis = MemoryLaborator()
        
        try:
            testThis.searchLaborator("1", "8")
            assert False
        except Exception as error:
            assert type(error) == RepositoryException
            assert error.returnErrors() == "Laboratorul nu exista"
        
        laborator = Laborator("1", "8", "1_4")
        testThis.rememberLaborator(laborator)
        
        try:
            assert laborator == testThis.searchLaborator("1", "8")
        except:
            assert False
        
    def __testRememberLaborator(self):
        """Test MemoryLaborator rememberLaborator function.
        """
        
        testThis = MemoryLaborator()
        
        laborator = Laborator("1", "8", "1_4")
        
        try:
            testThis.rememberLaborator(laborator)
            assert testThis.searchLaborator("1", "8") == laborator
        except:
            assert False
            
        try:
            testThis.rememberLaborator(laborator)
            assert False
        except Exception as error:
            assert type(error) == RepositoryException
            assert error.returnErrors() == "Atribuirea laborator student exista deja"
            
    def __testUpdateLaborator(self):
        """Test MemoryLaborator updateLaborator function.
        """
        
        testThis = MemoryLaborator()
        
        try:
            testThis.updateLaborator("1", "8", 10)
        except Exception as error:
            assert type(error) == RepositoryException
            assert error.returnErrors() == "Laboratorul nu exista"
        
        laborator = Laborator("1", "8", "1_4")
        testThis.rememberLaborator(laborator)
        
        try:
            testThis.updateLaborator("1", "8", 10)
            l = testThis.searchLaborator("1", "8")
            assert l.returnGrade() == 10
        except:
            assert False
            
    def __testReturnAllLaborators(self):
        """Test MemoryLaborator returnAllLaborators function.
        """
        
        testThis = MemoryLaborator()
        
        assert testThis.returnAllLaborators() == []
        
        laborator = Laborator("1", "8", "1_4")
        testThis.rememberLaborator(laborator)
        
        assert testThis.returnAllLaborators() == [laborator]
            
    def __testReturnLaboratorForNumber(self):
        """Test MemoryLaborator returnLaboratorForNumber function.
        """
        
        testThis = MemoryLaborator()
        
        assert testThis.returnAllLaborators() == []
        
        laborator = Laborator("1", "8", "1_4")
        testThis.rememberLaborator(laborator)
        
        assert testThis.returnLaboratorForNumber("5") == []
        assert testThis.returnLaboratorForNumber("1") == [laborator]
            
a = TestMemoryLaborator()
a.test()