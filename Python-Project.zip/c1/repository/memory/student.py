from domain.entities.student import Student
from repository.repositoryException import RepositoryException

class MemoryStudent:

    def __init__(self):
        """Creates new dictionary of students.
        """
        
        self.__students = {}
        
    def rememberStudent(self, student):
        """Remember in memory a student.
        
        Raises RepositoryException if a student
        with the same identification information exists already.
        
        student: Student
        """
        
        identification = student.returnIdentification()
        
        if identification in self.__students:
            raise RepositoryException("Legitimatia deja exista")
            
        self.__students[identification] = student
    
    def updateStudent(self, identification: str, student):
        """Update in memory the student with given identification.
        
        Raise RepositoryException if there is no student with the given identification.
        
        identification: str
        student: Student
        """
        if identification == student.returnIdentification():
            self.removeStudent(identification)
            self.rememberStudent(student)
        else:
            self.rememberStudent(student)
            self.removeStudent(identification)
    
    def searchStudent(self, identification: str):
        """Search the student with given identification from memory.
        
        Raise RepositoryException if no student
        with the given information exists.
        
        identification: str
        return: Student
        """
        
        if identification not in self.__students:
            raise RepositoryException("Legitimatia nu exista")
        
        a = self.__students[identification]
        
        return self.__students[identification]
    
    def removeStudent(self, identification: str):
        """Removes the student with given identification from memory.
        
        Raises RepositoryException if no student
        with the given identification exists.
        
        identification: str
        """
        
        if identification not in self.__students:
            raise RepositoryException("Legitimatia nu exista")
            
        del self.__students[identification]
        
    def returnAllStudents(self):
        """Returns all students.
        """
        
        return list(self.__students.values())
    
class TestMemoryStudent:
    
    def __init__(self):
        """This function does nothing.
        """
        print("", end = '')
        
    def test(self):
        """Test MemoryStudent class.
        """
        
        self.__testInit()
        
        self.__testRememberStudent()
        self.__testUpdateStudent()
        self.__testSearchStudent()
        self.__testRemoveStudent()
        self.__testReturnAllStudents()
        
    def __testInit(self):
        """Test MemoryStudent __init__ function.
        """
        assert True
        
    def __testRememberStudent(self):
        """Test MemoryStudent rememberProblem function.
        """
        testThis = MemoryStudent()
        firstStudent = Student("e", "", "")
        
        try:
            testThis.rememberStudent(firstStudent)
            assert True
        except RepositoryException:
            assert False
        
        try:
            testThis.rememberStudent(firstStudent)
            assert False
        except RepositoryException:
            assert True
            
    def __testUpdateStudent(self):
        """Test MemoryStudent updateStudent function.
        """
        testThis = MemoryStudent()
        
        firstStudent = Student("identification", "Name Name", "group53")
        testThis.rememberStudent(firstStudent)
        
        anotherStudent = Student("newIdentification", "NewName NewName", "newGroup")
        testThis.updateStudent("identification", anotherStudent)
        
        try:
        
            newStudent = testThis.searchStudent("newIdentification")
            assert newStudent.returnIdentification() == "newIdentification"
            assert newStudent.returnName() == "NewName NewName"
            assert newStudent.returnGroup() == "newGroup"
            
            try:
                student = testThis.searchStudent("identification")
                assert False
            except RepositoryException:
                assert True
            
        except RepositoryException:
            
            assert False
        
    def __testSearchStudent(self):
        """Test MemoryStudent searchProblem function.
        """
        testThis = MemoryStudent()
        
        try:
            testThis.searchStudent("e")
            assert False
        except RepositoryException:
            assert True
        
        firstStudent = Student("e", "", "")
        testThis.rememberStudent(firstStudent)
        
        try:
            testThis.searchStudent("e")
            assert True
        except RepositoryException:
            assert False
    
    def __testRemoveStudent(self):
        """Test MemoryStudent removeProblem function.
        """
        testThis = MemoryStudent()
        
        try:
            testThis.removeStudent("e")
            assert False
        except RepositoryException:
            assert True
        
        firstStudent = Student("e", "", "")
        testThis.rememberStudent(firstStudent)
        
        try:
            testThis.removeStudent("e")
            assert True
        except RepositoryException:
            assert False

    def __testReturnAllStudents(self):
        """Test MemoryStudent returnAllStudents function.
        """
        
        testThis = MemoryStudent()
        student1 = Student("1", "Name Name", "1")
        student2 = Student("2", "Name Name", "2")
        testThis.rememberStudent(student1)
        testThis.rememberStudent(student2)
        
        l = testThis.returnAllStudents()
        l2 = [student1, student2]
        
        for i in range(2):
            assert l[i].returnIdentification() == l2[i].returnIdentification()
            assert l[i].returnName() == l2[i].returnName()
            assert l[i].returnGroup() == l2[i].returnGroup()
        
a = TestMemoryStudent()
a.test()